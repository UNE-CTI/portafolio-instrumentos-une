# Mapa de instrumentos de apoyo empresarial · Uruguay (UNE-CTI)

Sitio interactivo que reúne los **74 instrumentos y 104 líneas** del portafolio empresarial B20 revisado al 30/10/2026,
para empresas, organizaciones intermedias e instituciones que diseñan instrumentos.

Stack: React 18 + Vite 5 + Framer Motion 12. Sin backend: el resultado es un sitio estático.

## Secciones

| Sección | Qué ofrece |
|---|---|
| Portada | Búsqueda libre, accesos por necesidad y cifras clave animadas |
| Etapas | Las cinco etapas funcionales, con el detalle de los apoyos frecuentes, las instituciones y las referencias expertas (37) |
| Panorama | Mapa de calor institución × etapa y barras por mecanismo, tipo de apoyo, capacidad y modalidad de acceso. Cada celda o barra filtra el explorador |
| Diferenciación | Para quienes diseñan instrumentos: comparar un instrumento con los más similares, evaluar la superposición de un perfil nuevo y un mapa de vacíos capacidad × etapa |
| Consulta guiada | Etapa + necesidad + tipo de solicitante, con los instrumentos ordenados por afinidad |
| Explorador | Filtros combinables, vista de fichas o tabla ordenable y ficha lateral con líneas, bases y fuentes |
| Metodología | Criterios y límites, instrumentos retirados, respaldo documental y confianza |

## Datos

`scripts/build_data.py` combina dos fuentes de `data-fuente/` y genera `src/data/portafolio.json`:

- `portafolio_data_30_10_2026.js`: define el universo, la etapa principal por instrumento (3 · 6 · 5 · 45 · 10, más 5 transversales),
  la modalidad de acceso, las URL oficiales, el rol de cada institución y las referencias expertas.
- `Clasificacion_etapas_B20_ajustada.xlsx`: aporta la clasificación por línea (etapas cubiertas, transversalidad, fundamento),
  las capacidades, los apoyos concretos y el público.

El Excel trae 76 instrumentos y 106 líneas. Se retiran de la selección B20 dos instrumentos:

- **ANDE · Formación en Asociatividad Empresarial**: el destinatario directo es el personal técnico de las instituciones representativas, no las empresas.
- **ANII · Vinculación con Expertos del Exterior**: las bases 2026 revisadas se orientan a instituciones de posgrado y prestadores de ASSE.

Las exclusiones están declaradas en `EXCLUIDAS` y el script verifica que no haya otras diferencias.

Para actualizar los datos:

```bash
npm run data
```

## Desarrollo y publicación

```bash
npm install
```

```bash
npm run dev
```

```bash
npm run build
```

`npm run build` genera `dist/`, que puede subirse tal cual a cualquier hosting estático (GitHub Pages, por ejemplo).
`npm run build:single` genera `dist-single/index.html`, un único archivo autocontenido.

## Notas de diseño

- Identidad institucional: azul UNE `#25408d`, acento terracota y colores por institución tomados del portafolio, siempre acompañados de la sigla.
- Las escalas secuenciales (mapas de calor) tienen pasos propios para el modo oscuro. Se respeta `prefers-reduced-motion` (`MotionConfig reducedMotion="user"`).
- Los patrones tipo 21st.dev (pestañas con indicador compartido, contador numérico, tarjeta con foco de luz, botón con brillo) están implementados localmente con Framer Motion. No se instaló ningún paquete del catálogo.
- La similitud de la sección Diferenciación usa el índice de Jaccard ponderado (apoyos 35 %, etapas 25 %, mecanismos 20 %, capacidades 20 %). Es orientativa.
