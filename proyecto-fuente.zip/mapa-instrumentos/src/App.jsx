import { useCallback, useState } from 'react'
import { MotionConfig } from 'framer-motion'
import Header from './components/Header'
import Hero from './components/Hero'
import Journey from './components/Journey'
import Panorama from './components/Panorama'
import Wizard from './components/Wizard'
import Explorer from './components/Explorer'
import Differentiation from './components/Differentiation'
import Drawer from './components/Drawer'
import Method from './components/Method'
import { UI, UNE } from './components/Logo'
import { FILTROS_VACIOS, TOTALES } from './lib/data'

export default function App() {
  const [filters, setFilters] = useState(FILTROS_VACIOS)
  const [open, setOpen] = useState(null)
  const explore = useCallback((partial) => {
    setFilters({ ...FILTROS_VACIOS, ...partial })
    setOpen(null)
    requestAnimationFrame(() => document.getElementById('explorador')?.scrollIntoView({ behavior: 'smooth' }))
  }, [])
  const close = useCallback(() => setOpen(null), [])

  return (
    <MotionConfig reducedMotion="user">
      <Header />
      <main>
        <Hero onSearch={(q) => explore({ q })} onNeed={(necesidad) => explore({ necesidad })} />
        <Journey onExplore={explore} onOpen={setOpen} />
        <Panorama onExplore={explore} onOpen={setOpen} />
        <Differentiation onExplore={explore} onOpen={setOpen} />
        <Wizard onExplore={explore} onOpen={setOpen} />
        <Explorer filters={filters} setFilters={setFilters} onOpen={setOpen} />
        <Method />
      </main>
      <footer className="footer">
        <div className="wrap">
          <div>
            <div className="footer-brand" aria-label="U+I · UNE">
              <UI height={24} />
              <span className="logo-rule" aria-hidden="true" />
              <UNE height={24} />
            </div>
            <p style={{ marginTop: 10 }}>Unidad Nacional de Evaluación del Sistema de Ciencia, Tecnología e Innovación</p>
          </div>
          <div style={{ maxWidth: 560 }}>
            <p>
              {TOTALES.instrumentos} instrumentos y {TOTALES.lineas} líneas del portafolio empresarial revisado.
              La información orienta la búsqueda y no sustituye las bases oficiales de cada institución.
            </p>
          </div>
        </div>
      </footer>
      <Drawer id={open} onClose={close} />
    </MotionConfig>
  )
}
