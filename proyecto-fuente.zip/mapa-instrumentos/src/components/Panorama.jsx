import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { BarList, Reveal, Tabs } from './motion'
import InstitutionMatrix, { seleccionar } from './InstitutionMatrix'
import { ETAPA_MAP, INST_MAP } from '../lib/data'

const TABS = [
  { id: 'mec', label: 'Mecanismo' },
  { id: 'apo', label: 'Tipo de apoyo' },
  { id: 'cap', label: 'Capacidad' },
  { id: 'mod', label: 'Acceso' },
]

// Valores de cada dimensión para un instrumento (cada instrumento suma una vez por valor)
const DIM = {
  mec: (i) => i.mecanismosTodos.map((m) => [m, m, { mecanismo: m }]),
  apo: (i) => i.apoyos.map((a) => [a.c, a.t, { apoyo: a.c }]),
  cap: (i) => i.capacidades.map((a) => [a.c, a.t, { capacidad: a.c }]),
  mod: (i) => i.modalidades.map((m) => [m, m, { modalidad: m }]),
}

function composicion(instrs, dim) {
  const m = new Map()
  instrs.forEach((ins) =>
    DIM[dim](ins).forEach(([key, label, f]) => {
      const r = m.get(key) || { key, label, f, value: 0 }
      r.value++
      m.set(key, r)
    }),
  )
  return [...m.values()].sort((a, b) => b.value - a.value || a.label.localeCompare(b.label, 'es'))
}

export default function Panorama({ onExplore, onOpen }) {
  const [tab, setTab] = useState('mec')
  const [modo, setModo] = useState('cobertura')
  const [sel, setSel] = useState({ i: null, e: null })

  const instrs = useMemo(() => seleccionar(sel, modo), [sel, modo])
  const filas = useMemo(() => composicion(instrs, tab).slice(0, 10), [instrs, tab])
  const total = composicion(instrs, tab).length
  const etiqueta = [sel.i && INST_MAP[sel.i].sigla, sel.e && ETAPA_MAP[sel.e].corto].filter(Boolean).join(' · ')
  const base = { ...(sel.i ? { institucion: sel.i } : {}), ...(sel.e ? { etapa: sel.e } : {}) }

  return (
    <section className="section" id="panorama">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Panorama del ecosistema</span>
            <h2>Quién apoya qué, y en qué momento</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              La oferta se concentra en la consolidación de empresas en operación; las etapas tempranas y de I+D tienen
              menos instrumentos y menos instituciones activas. La selección en la matriz define la composición que se
              muestra a la derecha.
            </p>
          </Reveal>
        </div>

        <div className="panorama">
          <Reveal className="card">
            <InstitutionMatrix modo={modo} setModo={setModo} sel={sel} setSel={setSel} onExplore={onExplore} onOpen={onOpen} />
          </Reveal>

          <Reveal className="card" delay={0.1}>
            <div className="card-head">
              <div>
                <h3>
                  Cómo se apoya{' '}
                  <AnimatePresence mode="wait" initial={false}>
                    <motion.span
                      key={etiqueta}
                      className="scope"
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.2 }}
                    >
                      {etiqueta || 'todo el portafolio'}
                    </motion.span>
                  </AnimatePresence>
                </h3>
                <p>
                  {instrs.length} instrumentos · {total} {tab === 'cap' ? 'capacidades' : tab === 'apo' ? 'tipos de apoyo' : tab === 'mec' ? 'mecanismos' : 'modalidades'} distintos
                  {total > 10 ? ' (se muestran los 10 más frecuentes)' : ''}
                </p>
              </div>
              <Tabs id="pan" items={TABS} value={tab} onChange={setTab} label="Dimensión" />
            </div>
            <BarList key={tab} rows={filas} onPick={(r) => onExplore({ ...base, ...r.f })} />
          </Reveal>
        </div>
      </div>
    </section>
  )
}
