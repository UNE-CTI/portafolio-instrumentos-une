import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, LayoutGroup, motion, useMotionTemplate, useMotionValue } from 'framer-motion'
import Icon from './Icon'
import { Counter, Reveal, Tabs, ease } from './motion'
import { ETAPAS, FILTROS_VACIOS, INST_MAP, INSTITUCIONES, NECESIDADES, OPCIONES, STAGES5, etiquetaFiltro, filtrar } from '../lib/data'

const PAGE = 12
const STRIP = { ideacion: 'Idea', id: 'I+D', marcha: 'Marcha', consolidacion: 'Consolid.', internacional: 'Internac.' }

export function StageStrip({ ins, labels = false }) {
  return (
    <div aria-label={`Etapas: ${ins.cobertura.map((c) => ETAPAS.find((e) => e.id === c).nombre).join(', ') || 'transversal'}`}>
      <div className="strip">
        {STAGES5.map((e) => (
          <i
            key={e.id}
            style={{
              background:
                ins.etapa === e.id ? 'var(--brand)' : ins.cobertura.includes(e.id) ? 'var(--seq-2)' : undefined,
            }}
          />
        ))}
      </div>
      {labels && (
        <div className="strip-labels" aria-hidden="true">
          {STAGES5.map((e) => (
            <span key={e.id} className={ins.cobertura.includes(e.id) ? 'on' : ''}>
              {STRIP[e.id]}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

function Card({ ins, onOpen, i }) {
  const mx = useMotionValue(-200)
  const my = useMotionValue(-200)
  const bg = useMotionTemplate`radial-gradient(320px circle at ${mx}px ${my}px, color-mix(in srgb, var(--brand) 9%, transparent), transparent 70%)`
  const inst = INST_MAP[ins.institucion]
  const etapa = ETAPAS.find((e) => e.id === ins.etapa)
  return (
    <motion.button
      layout
      className="icard"
      onClick={() => onOpen(ins.id)}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect()
        mx.set(e.clientX - r.left)
        my.set(e.clientY - r.top)
      }}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.35, ease, delay: Math.min(i % PAGE, 8) * 0.03 }}
      whileHover={{ y: -3 }}
    >
      <motion.span className="spot" style={{ background: bg }} />
      <span className="icard-top">
        <span title={inst.nombre}>
          <span className="dot" style={{ '--c': inst.color }} />
          {inst.sigla}
        </span>
        <span className={`tag ${ins.etapa === 'transversal' ? 'teal' : ''}`}>{etapa?.corto}</span>
      </span>
      <h3>{ins.nombre}</h3>
      <p>{ins.match[0].descripcion}</p>
      <StageStrip ins={ins} labels />
      <span className="tags">
        {ins.mecanismos.slice(0, 2).map((m) => (
          <span key={m} className="tag">
            {m.split(' / ')[0]}
          </span>
        ))}
        {ins.mecanismos.length > 2 && <span className="tag">+{ins.mecanismos.length - 2}</span>}
      </span>
      <span className="icard-foot">
        <span>
          {ins.match.length === ins.lineas.length
            ? `${ins.lineas.length} ${ins.lineas.length === 1 ? 'línea' : 'líneas'}`
            : `${ins.match.length} de ${ins.lineas.length} líneas coinciden`}
        </span>
        <span style={{ color: 'var(--brand-ink)', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          Ver ficha <Icon name="arrow" size={14} />
        </span>
      </span>
    </motion.button>
  )
}

const SORTS = {
  nombre: (a, b) => a.nombre.localeCompare(b.nombre, 'es'),
  institucion: (a, b) => a.institucion.localeCompare(b.institucion) || a.nombre.localeCompare(b.nombre, 'es'),
  etapa: (a, b) =>
    ETAPAS.findIndex((e) => e.id === a.etapa) - ETAPAS.findIndex((e) => e.id === b.etapa) || a.nombre.localeCompare(b.nombre, 'es'),
  lineas: (a, b) => b.match.length - a.match.length,
}

function Select({ label, value, onChange, children }) {
  return (
    <label className={`field select ${value ? 'active' : ''}`}>
      <span className="sr-only">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{label}</option>
        {children}
      </select>
    </label>
  )
}

export default function Explorer({ filters, setFilters, onOpen }) {
  const [view, setView] = useState('cards')
  const [sort, setSort] = useState({ key: 'etapa', dir: 1 })
  const [limit, setLimit] = useState(PAGE)
  const set = (k, v) => setFilters((f) => ({ ...f, [k]: v }))

  const results = useMemo(() => {
    const r = filtrar(filters)
    const s = [...r].sort(SORTS[sort.key])
    return sort.dir === 1 ? s : s.reverse()
  }, [filters, sort])
  const nLineas = results.reduce((n, r) => n + r.match.length, 0)

  useEffect(() => setLimit(PAGE), [filters])

  const activos = Object.entries(filters).filter(([, v]) => v)
  const th = (key, label) => (
    <th aria-sort={sort.key === key ? (sort.dir === 1 ? 'ascending' : 'descending') : undefined}>
      <button onClick={() => setSort((s) => ({ key, dir: s.key === key ? -s.dir : 1 }))}>
        {label}
        <Icon name={sort.key === key ? 'up' : 'sort'} size={12} style={{ transform: sort.key === key && sort.dir === -1 ? 'rotate(180deg)' : undefined }} />
      </button>
    </th>
  )

  return (
    <section className="section" id="explorador">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Explorador</span>
            <h2>Todos los instrumentos, filtrables</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              Búsqueda libre y filtros combinables. En cada ficha, la barra azul indica la etapa principal y las celestes,
              otras etapas cubiertas por sus líneas.
            </p>
          </Reveal>
        </div>

        <div className="toolbar">
          <div className="toolbar-row">
            <label className="field search">
              <Icon name="search" />
              <span className="sr-only">Buscar</span>
              <input
                type="search"
                value={filters.q}
                onChange={(e) => set('q', e.target.value)}
                placeholder="Buscar por nombre, apoyo, sector…"
              />
            </label>
            <Select label="Etapa" value={filters.etapa} onChange={(v) => set('etapa', v)}>
              {ETAPAS.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.nombre}
                </option>
              ))}
            </Select>
            <Select label="Institución" value={filters.institucion} onChange={(v) => set('institucion', v)}>
              {INSTITUCIONES.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.sigla} — {i.nombre}
                </option>
              ))}
            </Select>
            <Select label="Necesidad" value={filters.necesidad} onChange={(v) => set('necesidad', v)}>
              {NECESIDADES.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.label}
                </option>
              ))}
            </Select>
            <Select label="Mecanismo" value={filters.mecanismo} onChange={(v) => set('mecanismo', v)}>
              {OPCIONES.mecanismos.map(([m, n]) => (
                <option key={m} value={m}>
                  {m} ({n})
                </option>
              ))}
            </Select>
            <Select label="Tipo de apoyo" value={filters.apoyo} onChange={(v) => set('apoyo', v)}>
              {OPCIONES.apoyos.map((a) => (
                <option key={a.c} value={a.c}>
                  {a.t} ({a.n})
                </option>
              ))}
            </Select>
            <Select label="Acceso" value={filters.modalidad} onChange={(v) => set('modalidad', v)}>
              {OPCIONES.modalidades.map(([m, n]) => (
                <option key={m} value={m}>
                  {m} ({n})
                </option>
              ))}
            </Select>
          </div>
          <div className="active-filters">
            <span className="count" aria-live="polite">
              <b>
                <Counter value={results.length} duration={0.5} />
              </b>{' '}
              instrumentos · <b className="num">{nLineas}</b> líneas
            </span>
            <AnimatePresence initial={false}>
              {activos.map(([k, v]) => (
                  <motion.button
                    key={k}
                    layout
                    className="fchip"
                    onClick={() => set(k, '')}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    aria-label={`Quitar filtro ${etiquetaFiltro(k, v)}`}
                  >
                    <span>{etiquetaFiltro(k, v)}</span>
                    <Icon name="x" size={13} stroke={2.4} />
                  </motion.button>
                ))}
            </AnimatePresence>
            {activos.length > 0 && (
              <button className="linkbtn" onClick={() => setFilters(FILTROS_VACIOS)}>
                Limpiar todo
              </button>
            )}
            <span className="view-toggle">
              <Tabs
                id="view"
                label="Vista"
                value={view}
                onChange={setView}
                items={[
                  { id: 'cards', label: ' Fichas', icon: <Icon name="grid" size={14} /> },
                  { id: 'table', label: ' Tabla', icon: <Icon name="rows" size={14} /> },
                ]}
              />
            </span>
          </div>
        </div>

        {results.length === 0 ? (
          <motion.div className="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ marginTop: 18 }}>
            <b>No hay instrumentos con esos criterios</b>
            Puede ampliarse la búsqueda con otros términos o quitando filtros.
            <div style={{ marginTop: 14 }}>
              <button className="btn" onClick={() => setFilters(FILTROS_VACIOS)}>
                <Icon name="refresh" size={16} /> Ver todos
              </button>
            </div>
          </motion.div>
        ) : view === 'cards' ? (
          <LayoutGroup>
            <motion.div className="grid-cards" layout>
              <AnimatePresence mode="popLayout" initial={false}>
                {results.slice(0, limit).map((ins, i) => (
                  <Card key={ins.id} ins={ins} i={i} onOpen={onOpen} />
                ))}
              </AnimatePresence>
            </motion.div>
          </LayoutGroup>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  {th('nombre', 'Instrumento')}
                  {th('institucion', 'Institución')}
                  {th('etapa', 'Etapas')}
                  <th>Mecanismo</th>
                  <th>Acceso</th>
                  {th('lineas', 'Líneas')}
                </tr>
              </thead>
              <tbody>
                <AnimatePresence initial={false}>
                  {results.slice(0, limit).map((ins) => {
                    const inst = INST_MAP[ins.institucion]
                    return (
                      <motion.tr
                        key={ins.id}
                        layout="position"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.25 }}
                        onClick={() => onOpen(ins.id)}
                        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onOpen(ins.id))}
                        tabIndex={0}
                      >
                        <td className="name">
                          <b>{ins.nombre}</b>
                          <small>{ETAPAS.find((e) => e.id === ins.etapa)?.nombre}</small>
                        </td>
                        <td style={{ whiteSpace: 'nowrap', fontWeight: 650 }} title={inst.nombre}>
                          <span className="dot" style={{ '--c': inst.color }} />
                          {inst.sigla}
                        </td>
                        <td>
                          <StageStrip ins={ins} />
                        </td>
                        <td style={{ color: 'var(--ink-2)' }}>{ins.mecanismos.map((m) => m.split(' / ')[0]).join(' · ')}</td>
                        <td style={{ color: 'var(--ink-2)' }}>{ins.modalidades.join(' · ')}</td>
                        <td className="num" style={{ fontWeight: 700, textAlign: 'center' }}>
                          {ins.match.length}
                          {ins.match.length !== ins.lineas.length && <span style={{ color: 'var(--muted)', fontWeight: 500 }}>/{ins.lineas.length}</span>}
                        </td>
                      </motion.tr>
                    )
                  })}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        )}

        {results.length > PAGE && (
          <div className="more">
            <span className="num">
              Mostrando {Math.min(limit, results.length)} de {results.length}
            </span>
            {limit < results.length ? (
              <motion.button className="btn" onClick={() => setLimit((l) => l + PAGE)} whileTap={{ scale: 0.97 }}>
                Mostrar más
              </motion.button>
            ) : (
              <button className="linkbtn" onClick={() => setLimit(PAGE)}>
                Mostrar menos
              </button>
            )}
          </div>
        )}
      </div>
    </section>
  )
}
