import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { BarList, Reveal, ease } from './motion'
import { CRITERIOS, LINEAS } from '../lib/data'

const linkify = (t) =>
  t.split(/(https?:\/\/\S+)/g).map((p, i) =>
    /^https?:/.test(p) ? (
      <a key={i} href={p} target="_blank" rel="noopener noreferrer">
        {p}
      </a>
    ) : (
      p
    ),
  )

const count = (key, order) => {
  const m = new Map()
  LINEAS.forEach((l) => m.set(l[key], (m.get(l[key]) || 0) + 1))
  const rank = (k) => (order ? order.indexOf(k) : 0)
  return [...m.entries()]
    .sort((a, b) => rank(a[0]) - rank(b[0]) || b[1] - a[1])
    .map(([k, v]) => ({ key: k, label: k, value: v }))
}

export default function Method() {
  const [open, setOpen] = useState(0)
  return (
    <section className="section alt" id="metodologia">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Metodología y fuentes</span>
            <h2>Cómo leer este mapa</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              El mapa organiza la oferta en instrumentos y líneas de apoyo. Su clasificación se basa en la documentación oficial disponible y la correspondencia con las etapas empresariales se elaboró con revisión de expertos.
            </p>
          </Reveal>
        </div>
        <div className="method">
          <Reveal className="acc">
            {CRITERIOS.map((c, i) => (
              <div className="acc-item" key={c.aspecto}>
                <button onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}>
                  {c.aspecto}
                  <motion.span animate={{ rotate: open === i ? 45 : 0 }} style={{ display: 'inline-flex', color: 'var(--muted)' }}>
                    <Icon name="x" size={16} style={{ transform: 'rotate(45deg)' }} />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {open === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease }}
                      style={{ overflow: 'hidden' }}
                    >
                      <p className="acc-body">{linkify(c.criterio)}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </Reveal>
          <Reveal className="card" delay={0.1}>
            <div className="card-head">
              <div>
                <h3>Respaldo documental</h3>
                <p>Líneas según el tipo de fuente consultada</p>
              </div>
            </div>
            <BarList rows={count('cobertura')} color="var(--teal)" />
            <div className="card-head" style={{ marginTop: 26 }}>
              <div>
                <h3>Confianza de la clasificación</h3>
                <p>Líneas según el nivel declarado en la fuente</p>
              </div>
            </div>
            <BarList rows={count('confianza', ['Alta', 'Media-alta', 'Media', 'Baja'])} color="var(--ochre)" />
          </Reveal>
        </div>
      </div>
    </section>
  )
}
