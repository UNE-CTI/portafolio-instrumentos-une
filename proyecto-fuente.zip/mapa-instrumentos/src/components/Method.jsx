import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { Reveal, ease } from './motion'
import { CONTACTO, CRITERIOS, ETAPAS, INSTITUCIONES, INSTRUMENTOS, LINEAS, OPCIONES, TOTALES } from '../lib/data'

const linkify = (t) =>
  t.split(/(https?:\/\/\S+)/g).map((p, i) =>
    /^https?:/.test(p) ? (
      <a key={i} href={p} target="_blank" rel="noopener noreferrer">
        {p}
      </a>
    ) : (
      p
    ),
  )

const FINALIDADES = [...new Set(LINEAS.map((l) => l.finalidad))].sort((a, b) => a.localeCompare(b, 'es'))
const MECANISMOS = OPCIONES.mecanismos.map(([m]) => m)
const ETAPAS_TAX = ETAPAS.map((e) => (e.orden < 6 ? `${e.orden}. ${e.nombre}` : e.nombre))

function Acordeon({ items }) {
  const [open, setOpen] = useState(-1)
  return (
    <div className="acc">
      {items.map((c, i) => (
        <div className="acc-item" key={c.titulo}>
          <button onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}>
            {c.titulo}
            <motion.span animate={{ rotate: open === i ? 45 : 0 }} style={{ display: 'inline-flex', color: 'var(--muted)' }}>
              <Icon name="x" size={16} style={{ transform: 'rotate(45deg)' }} />
            </motion.span>
          </button>
          <AnimatePresence initial={false}>
            {open === i && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease }}
                style={{ overflow: 'hidden' }}
              >
                <div className="acc-body">{c.cuerpo}</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  )
}

function Fuentes() {
  return (
    <Acordeon
      items={INSTITUCIONES.map((a) => ({
        titulo: `${a.sigla} · ${INSTRUMENTOS.filter((i) => i.institucion === a.id).length} instrumentos`,
        cuerpo: (
          <ul className="fuentes">
            {INSTRUMENTOS.filter((i) => i.institucion === a.id)
              .sort((x, y) => x.nombre.localeCompare(y.nombre, 'es'))
              .map((i) => {
                const urls = [...new Set(i.lineas.flatMap((l) => [l.urlFicha, l.urlBases]).filter(Boolean))]
                return (
                  <li key={i.id}>
                    <b>{i.nombre}</b>
                    <span>
                      {urls.map((u, k) => (
                        <a key={u} href={u} target="_blank" rel="noopener noreferrer">
                          {/\.pdf($|\?)/i.test(u) ? 'Bases' : 'Ficha'}
                          {urls.length > 2 ? ` ${k + 1}` : ''}
                        </a>
                      ))}
                    </span>
                  </li>
                )
              })}
          </ul>
        ),
      }))}
    />
  )
}

function Reporte() {
  const [agencia, setAgencia] = useState(INSTITUCIONES[0].id)
  const [instrumento, setInstrumento] = useState('')
  const [texto, setTexto] = useState('')
  const [reporte, setReporte] = useState('')
  const [estado, setEstado] = useState('')
  const preparar = (e) => {
    e.preventDefault()
    setReporte(
      `Reporte de corrección del portafolio CTI\nAgencia: ${agencia}\nInstrumento o línea: ${instrumento}\n\nCorrección y evidencia:\n${texto}\n\nBase: portafolio empresarial B20 (${TOTALES.instrumentos} instrumentos, ${TOTALES.lineas} líneas)`,
    )
    setEstado('Reporte preparado. No se ha enviado.')
  }
  const copiar = async (valor, ok) => {
    try {
      await navigator.clipboard.writeText(valor)
      setEstado(ok)
    } catch {
      setEstado('Seleccione y copie el texto manualmente.')
    }
  }
  return (
    <div className="reporte">
      <p className="hint">
        {CONTACTO ? (
          <>
            Correcciones dirigidas a <b className="sel">{CONTACTO}</b>.{' '}
            <button className="linkbtn" onClick={() => copiar(CONTACTO, 'Dirección copiada.')}>
              Copiar dirección
            </button>
            <br />
            El formulario prepara el mensaje; el envío se realiza desde el correo de quien reporta.
          </>
        ) : (
          'Canal de envío: sin dato. El formulario permite preparar y copiar el reporte.'
        )}
      </p>
      <form onSubmit={preparar} className="reporte-form">
        <label>
          Agencia
          <select id="rep-agencia" value={agencia} onChange={(e) => setAgencia(e.target.value)} required>
            {INSTITUCIONES.map((a) => (
              <option key={a.id} value={a.id}>
                {a.sigla}
              </option>
            ))}
          </select>
        </label>
        <label>
          Instrumento o línea
          <input id="rep-instrumento" value={instrumento} onChange={(e) => setInstrumento(e.target.value)} required />
        </label>
        <label>
          Corrección y evidencia
          <textarea id="rep-texto" rows={4} value={texto} onChange={(e) => setTexto(e.target.value)} required />
        </label>
        <button className="btn btn-primary" type="submit">
          Preparar reporte
        </button>
      </form>
      <AnimatePresence>
        {reporte && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="reporte-form">
            <label>
              Reporte preparado
              <textarea id="rep-preparado" rows={8} readOnly value={reporte} />
            </label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn" onClick={() => copiar(reporte, 'Reporte copiado. No se ha enviado.')}>
                Copiar reporte
              </button>
              {CONTACTO && (
                <a
                  className="btn"
                  href={`mailto:${CONTACTO}?subject=${encodeURIComponent('Corrección del portafolio CTI')}&body=${encodeURIComponent(reporte)}`}
                >
                  Enviar por correo
                </a>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <p className="hint" role="status">
        {estado}
      </p>
    </div>
  )
}

export default function Method() {
  const nAgencias = INSTITUCIONES.length
  const adicionales = useMemo(
    () => CRITERIOS.filter((c) => c.aspecto !== 'Alcance').map((c) => ({ titulo: c.aspecto, cuerpo: <p>{linkify(c.criterio)}</p> })),
    [],
  )
  return (
    <section className="section alt" id="metodologia">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Metodología</span>
            <h2>Metodología y fuentes</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>La lectura requiere distinguir unidades de conteo, clasificación y límites de la evidencia.</p>
          </Reveal>
        </div>

        <div className="method">
          <Reveal as="article" className="card metodo">
            <h3>Alcance y unidades de análisis</h3>
            <p>
              Un instrumento es una intervención pública identificada en la base mediante un código propio. Una línea es una
              modalidad operativa de ese instrumento, con prestación, público y clasificación específicos. La suma de líneas no
              equivale al número de instrumentos. Los programas interinstitucionales se cuentan bajo la institución que
              registra la base.
            </p>
            <p>
              El subconjunto empresarial B20 contiene {TOTALES.instrumentos} instrumentos y {TOTALES.lineas} líneas de{' '}
              {nAgencias} agencias. Se incluyen cooperativas sociales y Asociativismo rural dentro del universo empresarial
              revisado. El universo describe la oferta empresarial relevada; no es un censo exhaustivo del sistema CTI ni de
              todas las actividades de sus instituciones.
            </p>

            <h3>Necesidades, mecanismos y etapas</h3>
            <p>
              Universo revisado: {TOTALES.instrumentos} instrumentos y {TOTALES.lineas} líneas B20. Las cinco etapas
              corresponden al mapa funcional revisado y la clasificación de los expertos es la que prevalece: los instrumentos
              con referencia experta toman su etapa y el resto se asigna por analogía con la referencia más cercana. Se conserva
              el desafío anterior en el registro de origen. Los instrumentos se cuentan por etapa principal; una línea solo cubre
              otra etapa cuando una referencia experta lo sostiene. Formación en Asociatividad Empresarial y Vinculación con
              Expertos del Exterior quedan fuera de este universo empresarial y permanecen en el portafolio general. Se
              incorporan los instrumentos de referencias expertas que no estaban en el portafolio, con su nombre vigente
              (por ejemplo, Ingenio figura como Incubación de empresas de LATU y PAE como PAIE de ANDE). La clasificación no
              confirma apertura ni elegibilidad.
            </p>
            <p>
              Las necesidades corresponden a las finalidades operativas de cada línea. Las fichas mantienen también la finalidad
              estratégica del instrumento. Un instrumento con varias líneas puede aparecer en más de una necesidad, mecanismo o
              etapa; por ello los conteos de instrumentos por esas categorías no son aditivos.
            </p>
            <p>
              Se preserva la taxonomía de mecanismos de la base: subsidios, crédito, capital, garantías, incentivos fiscales,
              servicios, acceso a activos, demanda o regulación, premios e información. Asistencia técnica, capacitación y
              servicios tecnológicos se consultan en las prestaciones de cada ficha. No se reclasifican como mecanismos
              excluyentes sin una regla validada, porque pueden combinarse en la misma línea.
            </p>
            <p>
              La trayectoria utiliza la clasificación funcional revisada: ideación y prueba, investigación y desarrollo, puesta en
              marcha, consolidación y crecimiento, e internacionalización y escalamiento. El eje transversal se presenta aparte.
              Esta clasificación no equivale a una ruta obligatoria ni a los requisitos de elegibilidad por etapa.
            </p>

            <h4 className="mini-head">Taxonomías de la base</h4>
            <div className="tax">
              {[
                ['Necesidades', FINALIDADES],
                ['Mecanismos', MECANISMOS],
                ['Etapas', ETAPAS_TAX],
              ].map(([nombre, valores]) => (
                <div key={nombre}>
                  <b>{nombre}</b>
                  <ul>
                    {valores.map((v) => (
                      <li key={v}>{v}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <h3>Criterios y límites de interpretación</h3>
            <p>
              La coincidencia de finalidad no prueba duplicación. El mapa muestra presencia de oferta registrada; para analizar
              complementariedades se requiere contrastar público, prestaciones y condiciones.
            </p>
            <p>
              El estado activo sigue la validación del relevamiento aportada por el usuario. No indica apertura permanente de
              convocatorias. Montos, porcentajes de cofinanciamiento, períodos de apertura y fechas individuales de relevamiento
              no están disponibles como campos estructurados y se muestran como sin dato. No se derivan de descripciones
              generales. Las fuentes deben consultarse para determinar condiciones vigentes.
            </p>
            <p>
              La actualización del sitio no sustituye una fecha de relevamiento o verificación de cada convocatoria.
            </p>
            <p>
              El catálogo no mide beneficiarios, recursos ejecutados, demanda insatisfecha, adicionalidad ni impacto. La ausencia
              en una celda describe el registro disponible, no necesariamente la ausencia de capacidades en Uruguay. La confianza
              documental de cada línea se conserva en su ficha. La actualización de la base no es automática.
            </p>

            <h3>Criterios de clasificación y revisión</h3>
            <Acordeon items={adicionales} />
          </Reveal>

          <Reveal as="aside" className="card" delay={0.1}>
            <h3 className="aside-h">Fuentes por agencia</h3>
            <Fuentes />
            <h3 className="aside-h" style={{ marginTop: 28 }}>
              Reporte de correcciones
            </h3>
            <Reporte />
          </Reveal>
        </div>
      </div>
    </section>
  )
}
