import { useMemo, useState } from 'react'
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion'
import Icon from './Icon'
import { Counter, Reveal, Tabs, ease } from './motion'
import { StageStrip } from './Explorer'
import {
  DIMENSIONES,
  FRECUENCIA,
  INST_MAP,
  INSTITUCIONES,
  INSTRUMENTOS,
  INSTR_MAP,
  MATRIZ_VACIOS,
  NOMBRE,
  OPCIONES,
  STAGES5,
  palabrasClave,
  perfilDe,
  similares,
  vectorTexto,
} from '../lib/data'

const TABS = [
  { id: 'comparar', label: 'Comparar un instrumento' },
  { id: 'perfil', label: 'Evaluar un perfil nuevo' },
  { id: 'vacios', label: 'Mapa de vacíos' },
]
const pct = (x) => Math.round(x * 100)
const plural = (n, uno, varios) => `${n} ${n === 1 ? uno : varios}`
const comparte = (c) => {
  const partes = [
    c.apoyos && plural(c.apoyos.length, 'apoyo', 'apoyos'),
    c.capacidades && plural(c.capacidades.length, 'capacidad', 'capacidades'),
    c.mecanismos?.length ? plural(c.mecanismos.length, 'mecanismo', 'mecanismos') : null,
  ].filter(Boolean)
  return partes.length ? `comparte ${partes.join(', ')}` : 'similitud por etapa'
}
const DIM_CORTO = { texto: 'Texto', etapas: 'Etapas', mecanismos: 'Mecan.', apoyos: 'Apoyos', capacidades: 'Capac.' }

function SimilarList({ items, onOpen, dims }) {
  if (!items.length)
    return (
      <div className="empty">
        <b>Sin instrumentos cercanos</b>
        Ningún instrumento comparte vocabulario ni apoyos y capacidades suficientes.
      </div>
    )
  return (
    <LayoutGroup>
      <motion.ol className="sim-list" layout>
        <AnimatePresence initial={false} mode="popLayout">
          {items.map((r, i) => {
            const inst = INST_MAP[r.ins.institucion]
            return (
              <motion.li
                key={r.ins.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.3, ease, delay: i * 0.03 }}
              >
                <button className="sim-item" onClick={() => onOpen(r.ins.id)}>
                  <span className="sim-pct num">
                    {pct(r.sim)}
                    <small>%</small>
                  </span>
                  <span className="sim-main">
                    <b>{r.ins.nombre}</b>
                    <small>
                      <span className="dot" style={{ '--c': inst.color }} />
                      {inst.sigla} · {comparte(r.comunes)}
                    </small>
                    {r.palabras.length > 0 && (
                      <span className="kw-row" aria-label="Palabras clave en común">
                        {r.palabras.map((w) => (
                          <span key={w} className="kw">
                            {w}
                          </span>
                        ))}
                      </span>
                    )}
                    <span className="dim-bars" style={{ gridTemplateColumns: `repeat(${dims.length}, minmax(0, 1fr))` }} aria-label="Similitud por dimensión">
                      {dims.map((d) => (
                        <span key={d.id} className="dim" title={`${d.label}: ${pct(r.porDim[d.id])}%`}>
                          <em>{DIM_CORTO[d.id]}</em>
                          <span className="dim-track">
                            <motion.i
                              initial={{ scaleX: 0 }}
                              animate={{ scaleX: Math.min(1, r.porDim[d.id]) }}
                              transition={{ duration: 0.7, ease }}
                            />
                          </span>
                        </span>
                      ))}
                    </span>
                  </span>
                </button>
              </motion.li>
            )
          })}
        </AnimatePresence>
      </motion.ol>
    </LayoutGroup>
  )
}

/** Barras de rareza: cuántos otros instrumentos ofrecen cada componente. */
function Rareza({ dim, codes, self = 0 }) {
  const max = Math.max(...Object.values(FRECUENCIA[dim]))
  const rows = codes
    .map((c) => ({ c, n: (FRECUENCIA[dim][c] || 0) - self }))
    .sort((a, b) => a.n - b.n)
  return (
    <div className="bars">
      {rows.map((r, i) => (
        <div key={r.c} className="bar-row">
          <span className="bar-label">
            {NOMBRE[dim][r.c]}
            {r.n === 0 && <span className="tag teal" style={{ marginLeft: 6 }}>único</span>}
          </span>
          <span className="bar-value">{r.n}</span>
          <span className="bar-track">
            <motion.span
              className="bar-fill"
              style={{ display: 'block', width: `${(r.n / max) * 100}%`, background: 'var(--ochre)' }}
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 0.7, ease, delay: i * 0.04 }}
            />
          </span>
        </div>
      ))}
    </div>
  )
}

function Comparar({ onOpen }) {
  const [id, setId] = useState(INSTRUMENTOS.find((i) => i.nombre.startsWith('Activa'))?.id || INSTRUMENTOS[0].id)
  const ins = INSTR_MAP[id]
  const inst = INST_MAP[ins.institucion]
  const sims = useMemo(() => similares(perfilDe(ins), ins.id).slice(0, 6), [ins])
  return (
    <div className="diff-grid">
      <div className="card">
        <label className="field select" style={{ marginBottom: 18 }}>
          <span className="sr-only">Instrumento a comparar</span>
          <select value={id} onChange={(e) => setId(e.target.value)}>
            {INSTITUCIONES.map((g) => (
              <optgroup key={g.id} label={g.sigla}>
                {INSTRUMENTOS.filter((i) => i.institucion === g.id)
                  .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))
                  .map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.nombre}
                    </option>
                  ))}
              </optgroup>
            ))}
          </select>
        </label>
        <AnimatePresence mode="wait">
          <motion.div key={id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
            <p className="eyebrow">
              <span className="dot" style={{ '--c': inst.color }} />
              {inst.sigla} · {ins.lineas.length} {ins.lineas.length === 1 ? 'línea' : 'líneas'}
            </p>
            <h3 className="diff-title">{ins.nombre}</h3>
            <StageStrip ins={ins} labels />
            <h4 className="mini-head">Palabras clave · {palabrasClave(ins.id).origen === 'bases' ? 'según bases oficiales' : 'según el portafolio'}</h4>
            <div className="kw-row">
              {palabrasClave(ins.id).palabras.map((w) => (
                <span key={w} className="kw strong">
                  {w}
                </span>
              ))}
            </div>
            <h4 className="mini-head">Apoyos · cuántos otros instrumentos los ofrecen</h4>
            <Rareza dim="apoyos" codes={ins.apoyos.map((a) => a.c)} self={1} />
            <h4 className="mini-head">Capacidades · cuántos otros instrumentos las trabajan</h4>
            <Rareza dim="capacidades" codes={ins.capacidades.map((a) => a.c)} self={1} />
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="card">
        <div className="card-head">
          <div>
            <h3>Instrumentos más similares</h3>
            <p>Cercanía de palabras clave y coincidencia de apoyos, capacidades, mecanismo y etapa</p>
          </div>
        </div>
        <SimilarList items={sims} onOpen={onOpen} dims={DIMENSIONES} />
      </div>
    </div>
  )
}

function Toggle({ on, onClick, children, n }) {
  return (
    <button className="toggle" aria-pressed={on} onClick={onClick}>
      {children}
      {n != null && <small className="num">{n}</small>}
    </button>
  )
}

const VACIO = { texto: new Map(), etapas: new Set(), mecanismos: new Set(), apoyos: new Set(), capacidades: new Set() }

function Perfil({ onOpen }) {
  const [p, setP] = useState(VACIO)
  const [desc, setDesc] = useState('')
  const escribir = (t) => {
    setDesc(t)
    setP((s) => ({ ...s, texto: vectorTexto(t) }))
  }
  const flip = (dim, v) =>
    setP((s) => {
      const n = new Set(s[dim])
      n.has(v) ? n.delete(v) : n.add(v)
      return { ...s, [dim]: n }
    })
  const total = DIMENSIONES.reduce((s, d) => s + p[d.id].size, 0)
  const limpiar = () => {
    setP(VACIO)
    setDesc('')
  }
  const sims = useMemo(() => similares(p), [p])
  const dims = DIMENSIONES.filter((d) => p[d.id].size)
  const cercanos = sims.filter((r) => r.sim >= 0.35).length
  const nivel = cercanos >= 6 ? ['Alta', 'var(--accent)'] : cercanos >= 2 ? ['Moderada', 'var(--ochre)'] : ['Baja', 'var(--teal)']

  return (
    <div className="diff-grid">
      <div className="card">
        <div className="card-head">
          <div>
            <h3>Perfil del instrumento en diseño</h3>
            <p>Marque las características previstas; el análisis se actualiza al instante.</p>
          </div>
          {total > 0 && (
            <button className="linkbtn" onClick={limpiar}>
              Limpiar
            </button>
          )}
        </div>
        <label className="mini-head" htmlFor="perfil-desc" style={{ display: 'block' }}>
          Descripción breve
        </label>
        <textarea
          id="perfil-desc"
          className="desc"
          rows={3}
          value={desc}
          onChange={(e) => escribir(e.target.value)}
          placeholder="Ej.: subsidio para capacitar a trabajadores de empresas exportadoras en idiomas y competencias digitales"
        />
        <h4 className="mini-head">Etapas</h4>
        <div className="toggles">
          {STAGES5.map((e) => (
            <Toggle key={e.id} on={p.etapas.has(e.id)} onClick={() => flip('etapas', e.id)}>
              {e.orden}. {e.corto}
            </Toggle>
          ))}
        </div>
        <h4 className="mini-head">Mecanismo</h4>
        <div className="toggles">
          {OPCIONES.mecanismos.map(([m, n]) => (
            <Toggle key={m} on={p.mecanismos.has(m)} onClick={() => flip('mecanismos', m)} n={n}>
              {m}
            </Toggle>
          ))}
        </div>
        <h4 className="mini-head">Apoyos concretos</h4>
        <div className="toggles">
          {OPCIONES.apoyos.map((a) => (
            <Toggle key={a.c} on={p.apoyos.has(a.c)} onClick={() => flip('apoyos', a.c)} n={a.n}>
              {a.t}
            </Toggle>
          ))}
        </div>
        <h4 className="mini-head">Capacidades que fortalece</h4>
        <div className="toggles">
          {OPCIONES.capacidades.map((a) => (
            <Toggle key={a.c} on={p.capacidades.has(a.c)} onClick={() => flip('capacidades', a.c)} n={a.n}>
              {a.t}
            </Toggle>
          ))}
        </div>
        <p className="hint">El número junto a cada opción indica cuántos instrumentos vigentes la incluyen.</p>
      </div>

      <div className="card sticky-card">
        {total === 0 ? (
          <div className="empty">
            <b>Defina al menos una característica</b>
            Se calculará la superposición con los {INSTRUMENTOS.length} instrumentos del portafolio.
          </div>
        ) : (
          <>
            <div className="overlap">
              <div>
                <span className="overlap-n" style={{ color: nivel[1] }}>
                  <Counter value={cercanos} duration={0.6} />
                </span>
                <span className="overlap-l">
                  instrumentos con similitud ≥ 35%
                  <b style={{ color: nivel[1] }}>Superposición {nivel[0].toLowerCase()}</b>
                </span>
              </div>
              <div className="overlap-scale" aria-hidden="true">
                {['Baja', 'Moderada', 'Alta'].map((l) => (
                  <span key={l} className={l === nivel[0] ? 'on' : ''}>
                    {l}
                  </span>
                ))}
              </div>
            </div>
            <h4 className="mini-head">Instrumentos con mayor superposición</h4>
            <SimilarList items={sims.slice(0, 5)} onOpen={onOpen} dims={dims} />
            {(p.apoyos.size > 0 || p.capacidades.size > 0) && (
              <>
                <h4 className="mini-head">Componentes del perfil · instrumentos que ya los ofrecen</h4>
                {p.apoyos.size > 0 && <Rareza dim="apoyos" codes={[...p.apoyos]} />}
                {p.capacidades.size > 0 && <Rareza dim="capacidades" codes={[...p.capacidades]} />}
              </>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function Vacios({ onExplore }) {
  const max = Math.max(...MATRIZ_VACIOS.flatMap((r) => r.cells.map((c) => c.ins.length)))
  const step = (n) => (n === 0 ? 0 : Math.max(1, Math.ceil((n / max) * 7)))
  const vacios = MATRIZ_VACIOS.flatMap((r) => r.cells.filter((c) => c.ins.length === 0)).length
  const escasos = MATRIZ_VACIOS.flatMap((r) => r.cells.filter((c) => c.ins.length > 0 && c.ins.length <= 2)).length
  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3>Capacidad empresarial × etapa</h3>
          <p>
            Instrumentos con al menos una línea que trabaja la capacidad en esa etapa. {vacios} combinaciones sin oferta y{' '}
            {escasos} con uno o dos instrumentos.
          </p>
        </div>
        <span className="heat-legend" style={{ marginTop: 0 }}>
          <i className="gap-swatch" /> Sin oferta
          {[1, 3, 5, 7].map((s) => (
            <i key={s} style={{ background: `var(--seq-${s})` }} />
          ))}
          Más · máx. {max}
        </span>
      </div>
      <div className="heat-scroll">
        <motion.div className="heat-grid gaps" initial="hidden" animate="show" role="table" aria-label="Instrumentos por capacidad y etapa">
          <div role="row" style={{ display: 'contents' }}>
            <span role="columnheader" />
            {STAGES5.map((e) => (
              <span key={e.id} role="columnheader" className="heat-colhead">
                {e.corto}
              </span>
            ))}
          </div>
          {MATRIZ_VACIOS.map((r, ri) => (
            <div role="row" key={r.cap.c} style={{ display: 'contents' }}>
              <span role="rowheader" className="heat-rowhead wrap-head">
                {r.cap.t}
              </span>
              {r.cells.map((c, ci) => {
                const n = c.ins.length
                const s = step(n)
                return (
                  <motion.button
                    role="cell"
                    key={c.etapa.id}
                    className={`heat-cell s${s} ${n === 0 ? 'gap' : ''}`}
                    disabled={!n}
                    title={
                      n
                        ? `${r.cap.t} · ${c.etapa.nombre}: ${n} instrumentos (${c.ins.slice(0, 4).map((i) => i.nombre).join(', ')}${n > 4 ? '…' : ''})`
                        : `${r.cap.t} · ${c.etapa.nombre}: sin oferta registrada`
                    }
                    style={{
                      background: n ? `var(--seq-${s})` : undefined,
                    }}
                    variants={{ hidden: { scale: 0.82 }, show: { scale: 1, transition: { duration: 0.4, ease, delay: 0.015 * (ri + ci) } } }}
                    onClick={() => onExplore({ capacidad: r.cap.c, etapa: c.etapa.id })}
                  >
                    {n || '—'}
                  </motion.button>
                )
              })}
            </div>
          ))}
        </motion.div>
      </div>
      <p className="hint" style={{ marginTop: 14 }}>
        Las celdas vacías o con baja densidad señalan espacios potenciales de diferenciación; no implican por sí mismas una
        necesidad desatendida, que debe contrastarse con la demanda empresarial.
      </p>
    </div>
  )
}

export default function Differentiation({ onOpen, onExplore }) {
  const [tab, setTab] = useState('comparar')
  return (
    <section className="section alt" id="diferenciacion">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Para el diseño de instrumentos</span>
            <h2>Similitudes, superposiciones y espacios vacíos</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              Herramientas para instituciones que diseñan o rediseñan instrumentos: comparar un instrumento con el resto de la
              oferta, estimar la superposición de un perfil nuevo e identificar combinaciones de capacidad y etapa con poca o
              ninguna cobertura.
            </p>
          </Reveal>
        </div>
        <Reveal style={{ marginBottom: 20 }}>
          <Tabs id="diff" items={TABS} value={tab} onChange={setTab} label="Herramienta" />
        </Reveal>
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3, ease }}
          >
            {tab === 'comparar' && <Comparar onOpen={onOpen} />}
            {tab === 'perfil' && <Perfil onOpen={onOpen} />}
            {tab === 'vacios' && <Vacios onExplore={onExplore} />}
          </motion.div>
        </AnimatePresence>
        <p className="hint" style={{ marginTop: 16, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <Icon name="help" size={16} style={{ flexShrink: 0, marginTop: 2 }} />
          Similitud: cercanía de palabras clave (TF-IDF sobre nombre, líneas, descripciones, sector y, cuando se pudieron
          leer, las bases oficiales; 45%) y coincidencia
          de apoyos (20%), capacidades (15%), mecanismo (12%) y etapa (8%). Solo se listan instrumentos con vocabulario en
          común o con apoyos y capacidades coincidentes. Es una medida orientativa: no compara bases ni montos.
        </p>
      </div>
    </section>
  )
}
