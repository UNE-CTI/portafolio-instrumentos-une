import { useEffect, useState } from 'react'
import { motion, useScroll, useSpring } from 'framer-motion'
import Logo from './Logo'

const LINKS = [
  ['etapas', 'Etapas'],
  ['panorama', 'Panorama'],
  ['diferenciacion', 'Diferenciación'],
  ['asistente', 'Consulta'],
  ['explorador', 'Explorador'],
  ['metodologia', 'Metodología'],
]

export default function Header() {
  const [active, setActive] = useState('')
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 140, damping: 30 })

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' },
    )
    LINKS.forEach(([id]) => {
      const el = document.getElementById(id)
      el && io.observe(el)
    })
    return () => io.disconnect()
  }, [])

  return (
    <header className="topbar">
      <div className="wrap">
        <a className="identity" href="#inicio" aria-label="UNE · Portafolio de instrumentos de CTI, inicio">
          <Logo height={26} />
          <span className="tool">Portafolio de instrumentos de CTI</span>
        </a>
        <nav className="nav" aria-label="Secciones">
          {LINKS.map(([id, label]) => (
            <a key={id} href={`#${id}`} aria-current={active === id}>
              {active === id && (
                <motion.span layoutId="nav-pill" className="nav-pill" transition={{ type: 'spring', stiffness: 380, damping: 32 }} />
              )}
              {label}
            </a>
          ))}
        </nav>
      </div>
      <motion.div className="progress" style={{ scaleX }} />
    </header>
  )
}
