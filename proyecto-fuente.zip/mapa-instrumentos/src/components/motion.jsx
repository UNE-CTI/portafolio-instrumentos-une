import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, animate, motion, useReducedMotion } from 'framer-motion'

export const ease = [0.22, 1, 0.36, 1]

/** Desliza su contenido al entrar en pantalla; siempre visible (sin opacidad 0 en reposo). */
export function Reveal({ children, delay = 0, y = 18, as = 'div', ...rest }) {
  const M = motion[as]
  return (
    <M
      initial={{ y }}
      whileInView={{ y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.6, ease, delay }}
      {...rest}
    >
      {children}
    </M>
  )
}

/** Contador numérico animado al cargar (patrón “number ticker”). */
export function Counter({ value, duration = 1.4 }) {
  const ref = useRef(null)
  const reduce = useReducedMotion()
  const [n, setN] = useState(reduce ? value : 0)
  const last = useRef(0)
  useEffect(() => {
    if (reduce) {
      setN(value)
      return
    }
    const c = animate(last.current, value, {
      duration: last.current === 0 ? duration : 0.5,
      ease,
      onUpdate: (v) => setN(Math.round(v)),
    })
    last.current = value
    return () => c.stop()
  }, [value, duration, reduce])
  return (
    <span ref={ref} className="num">
      {n}
    </span>
  )
}

/** Pestañas con indicador animado compartido (layoutId). */
export function Tabs({ id, items, value, onChange, label }) {
  return (
    <div className="tabs" role="tablist" aria-label={label}>
      {items.map((it) => (
        <button
          key={it.id}
          role="tab"
          aria-selected={value === it.id}
          className="tab"
          onClick={() => onChange(it.id)}
        >
          {value === it.id && (
            <motion.span layoutId={`pill-${id}`} className="tab-pill" transition={{ type: 'spring', stiffness: 420, damping: 34 }} />
          )}
          {it.icon}
          {it.label}
        </button>
      ))}
    </div>
  )
}

/** Lista de barras horizontales de una sola serie; cada fila puede ser un filtro.
 *  Las barras animan su ancho y las filas se reordenan con layout cuando cambian los datos. */
export function BarList({ rows, max, onPick, color = 'var(--brand)', unit = 'instrumentos' }) {
  const m = max ?? Math.max(...rows.map((r) => r.value), 1)
  return (
    <div className="bars">
      <AnimatePresence initial={false}>
        {rows.map((r, i) => {
          const Comp = onPick ? motion.button : motion.div
          return (
            <Comp
              key={r.key}
              layout="position"
              className="bar-row"
              onClick={onPick ? () => onPick(r) : undefined}
              title={onPick ? `Ver ${r.value} ${unit}: ${r.label}` : undefined}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3, ease }}
            >
              <span className="bar-label">
                {r.color && <span className="dot" style={{ '--c': r.color }} />}
                {r.label}
              </span>
              <span className="bar-value num">{r.value}</span>
              <span className="bar-track">
                <motion.span
                  className="bar-fill"
                  style={{ display: 'block', background: color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${(r.value / m) * 100}%` }}
                  transition={{ duration: 0.7, ease, delay: Math.min(i, 10) * 0.03 }}
                />
              </span>
            </Comp>
          )
        })}
      </AnimatePresence>
    </div>
  )
}
