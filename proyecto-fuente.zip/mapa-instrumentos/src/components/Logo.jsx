// Logotipo UNE reconstruido en vectores: trazo continuo de extremos redondeados.
const W = 46 // grosor del trazo
const r = 37 // radio de los arcos de la N

const U = (x) => `M${x + 23} 23 V100 A77 77 0 0 0 ${x + 177} 100 V23`
const N = (x) =>
  `M${x + 23} 177 V${23 + r} A${r} ${r} 0 0 1 ${x + 23 + 2 * r} ${23 + r} V${177 - r} A${r} ${r} 0 0 0 ${x + 23 + 4 * r} ${177 - r} V23`
const E = (x) =>
  `M${x + 167} 23 H${x + 61.5} A38.5 38.5 0 0 0 ${x + 61.5} 100 H${x + 167} M${x + 61.5} 100 A38.5 38.5 0 0 0 ${x + 61.5} 177 H${x + 167}`
// U+I
const PLUS = (x) => `M${x + 23} 100 H${x + 157} M${x + 90} 33 V167`
const I = (x) => `M${x + 23} 23 H${x + 167} M${x + 95} 23 V177 M${x + 23} 177 H${x + 167}`

function Marca({ d, width, height = 32, title }) {
  return (
    <svg viewBox={`0 0 ${width} 200`} height={height} width={(height * width) / 200} role="img" aria-label={title}>
      <path d={d} fill="none" stroke="currentColor" strokeWidth={W} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export const UNE = ({ height }) => <Marca d={`${U(0)} ${N(245)} ${E(484)}`} width={674} height={height} title="UNE" />
export const UI = ({ height }) => <Marca d={`${U(0)} ${PLUS(225)} ${I(430)}`} width={620} height={height} title="U+I" />

export default function Logo({ height = 30 }) {
  return (
    <span className="logo">
      <UNE height={height} />
      <span className="logo-rule" aria-hidden="true" />
      <span className="logo-name">
        Unidad Nacional de Evaluación del Sistema
        <br />
        de Ciencia, Tecnología e Innovación
      </span>
    </span>
  )
}
