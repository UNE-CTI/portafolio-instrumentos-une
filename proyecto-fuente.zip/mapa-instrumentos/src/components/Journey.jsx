import * as w from 'react'
import { STAGES5, REFERENCIAS, INSTR_MAP, INSTRUMENTOS, ETAPA_TEXTO } from '../lib/data'
export default function Journey({onExplore,onOpen}) {
const h=w.createElement; const [open,setOpen]=w.useState('');
const stats=STAGES5.map(stage=>{const refs=REFERENCIAS.filter(r=>r.etapa===stage.id);const ids=[...new Set(refs.flatMap(r=>r.instrumentos).filter(id=>INSTR_MAP[id]))];return {...stage,refs,ids,documentados:INSTRUMENTOS.filter(i=>i.cobertura.includes(stage.id))}});
const sel=stats.find(e=>e.id===open);
return h('section',{className:'section alt',id:'etapas'},h('div',{className:'wrap'},
h('div',{className:'section-head'},h('div',null,h('span',{className:'kicker'},'Trayectoria empresarial'),h('h2',null,'Cinco etapas de la trayectoria empresarial')),h('p',null,'La referencia experta es la clasificación principal de esta sección. Las etapas describen la función del apoyo, no la edad de la empresa. La cobertura identificada en las bases se presenta como información complementaria.')),
h('div',{className:'journey'},h('div',{className:'stages'},stats.map(e=>h('button',{key:e.id,className:'stage',onClick:()=>setOpen(open===e.id?'':e.id),'aria-expanded':open===e.id,'aria-controls':'stage-panel'},h('span',{className:'stage-num',style:{background:'var(--brand)'}},e.orden),h('h3',null,e.nombre),h('p',null,ETAPA_TEXTO[e.id]),h('div',{className:'stage-count'},h('b',null,e.ids.length),h('span',null,'instrumentos según referencia experta')),h('span',{className:'stage-more'},e.ids.length+' instrumentos con ficha vinculada'))))),
sel&&h('div',{id:'stage-panel',className:'stage-panel'},h('div',{className:'stage-panel-inner'},
h('div',null,h('h4',null,'Etapa '+sel.orden),h('p',{className:'big'},sel.nombre),h('p',null,sel.ids.length+' instrumentos clasificados en esta etapa según la referencia experta.')),
h('div',null,h('h4',null,'Clasificación principal · referencia experta ('+sel.ids.length+')'),h('div',{className:'bm-list'},sel.ids.map(id=>h('button',{key:id,className:'bm-item',onClick:()=>onOpen(id)},INSTR_MAP[id].nombre)))),
h('div',null,h('h4',null,'Información complementaria · bases'),h('p',{className:'hint'},'Cobertura según la documentación: '+sel.documentados.length+' instrumentos. Puede diferir de la referencia experta.'),h('div',{className:'bm-list'},sel.documentados.map(i=>h('button',{key:i.id,className:'bm-item',onClick:()=>onOpen(i.id)},i.nombre))),h('button',{className:'btn',onClick:()=>onExplore({etapa:sel.id})},'Explorar cobertura documental'))))));
}