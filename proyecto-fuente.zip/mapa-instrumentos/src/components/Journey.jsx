import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { Counter, Reveal, ease } from './motion'
import { ETAPA_MAP, ETAPA_TEXTO, INST_MAP, INSTRUMENTOS, INSTR_MAP, REFERENCIAS, STAGES5 } from '../lib/data'

const stats = STAGES5.map((e) => {
  const principal = INSTRUMENTOS.filter((i) => i.etapa === e.id)
  const cobertura = INSTRUMENTOS.filter((i) => i.cobertura.includes(e.id))
  // instrumentos con otra etapa principal que cubren esta etapa con alguna de sus líneas
  const extra = cobertura.filter((i) => i.etapa !== e.id)
  return { ...e, principal, cobertura, extra }
})
const MAX = Math.max(...stats.map((s) => s.principal.length))
const transversales = INSTRUMENTOS.filter((i) => i.etapa === 'transversal')

export default function Journey({ onExplore, onOpen }) {
  const [open, setOpen] = useState('')
  const sel = stats.find((s) => s.id === open)
  const panelRef = useRef(null)

  // el panel se abre debajo de la grilla: en pantallas angostas se lleva a la vista
  useEffect(() => {
    if (!open) return
    const t = setTimeout(() => panelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 480)
    return () => clearTimeout(t)
  }, [open])

  const refs = sel ? REFERENCIAS.filter((r) => r.etapa === sel.id) : []

  return (
    <section className="section alt" id="etapas">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Trayectoria empresarial</span>
            <h2>Cinco etapas de la trayectoria empresarial</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              Las etapas describen la función del apoyo, no la edad de la empresa: una empresa consolidada también puede
              ejecutar un proyecto de I+D. Cada etapa muestra qué tipo de apoyo predomina, qué instituciones la cubren y qué referencias expertas se le asocian.
            </p>
          </Reveal>
        </div>

        <div className="journey">
          <div className="journey-track" aria-hidden="true">
            <motion.div
              className="journey-track-fill"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1.6, ease }}
            />
          </div>
          <div className="stages">
            {stats.map((s, i) => (
              <motion.button
                key={s.id}
                className="stage"
                aria-expanded={open === s.id}
                aria-controls="stage-panel"
                onClick={() => setOpen(open === s.id ? '' : s.id)}
                initial={{ y: 24 }}
                whileInView={{ y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.6, ease, delay: 0.1 * i }}
                whileHover={{ y: -4 }}
              >
                <span className="stage-num" style={{ background: 'var(--brand)' }}>
                  {s.orden}
                </span>
                <h3>{s.nombre}</h3>
                <p>{ETAPA_TEXTO[s.id]}</p>
                <div className="stage-count">
                  <b>
                    <Counter value={s.principal.length} />
                  </b>
                  <span>instrumentos como etapa principal</span>
                </div>
                <div className="stage-mini" aria-hidden="true">
                  <motion.i
                    style={{ background: 'var(--brand)', transformOrigin: '0 50%' }}
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: s.principal.length / MAX }}
                    transition={{ duration: 1, ease, delay: 0.3 + 0.1 * i }}
                  />
                </div>
                <span className="stage-more">
                  {s.extra.length
                    ? `+${s.extra.length} ${s.extra.length === 1 ? 'la cubre' : 'la cubren'} con alguna línea`
                    : 'Ver instrumentos y referencias'}
                  <motion.span animate={{ rotate: open === s.id ? 180 : 0 }} style={{ display: 'inline-flex' }}>
                    <Icon name="chev" size={14} />
                  </motion.span>
                </span>
              </motion.button>
            ))}
          </div>
        </div>

        <AnimatePresence initial={false} mode="wait">
          {sel && (
            <motion.div
              key={sel.id}
              id="stage-panel"
              ref={panelRef}
              className="stage-panel"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.45, ease }}
            >
              <div className="stage-panel-inner">
                <div>
                  <h4>Etapa {sel.orden}</h4>
                  <p className="big">{sel.nombre}</p>
                  <p style={{ color: 'var(--ink-2)', fontSize: 14, marginBottom: 16 }}>
                    {sel.principal.length} instrumentos la tienen como etapa principal y {sel.extra.length} más, con otra etapa
                    principal, {sel.extra.length === 1 ? 'la cubre' : 'la cubren'} con alguna de sus líneas:{' '}
                    {sel.cobertura.length} en total.
                  </p>
                  <button className="btn btn-primary" onClick={() => onExplore({ etapa: sel.id })}>
                    Ver los {sel.cobertura.length} instrumentos
                    <Icon name="arrow" size={16} />
                  </button>
                </div>
                <div>
                  <h4>Etapa principal ({sel.principal.length})</h4>
                  <div className="bm-list">
                    {sel.principal.slice(0, 12).map((i, k) => (
                      <motion.button
                        key={i.id}
                        className="bm-item"
                        onClick={() => onOpen(i.id)}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.15 + k * 0.03 }}
                      >
                        <span className="dot" style={{ '--c': INST_MAP[i.institucion].color }} />
                        {i.nombre}
                      </motion.button>
                    ))}
                    {sel.principal.length > 12 && (
                      <button className="linkbtn" onClick={() => onExplore({ etapa: sel.id })}>
                        y {sel.principal.length - 12} más
                      </button>
                    )}
                  </div>
                  {sel.extra.length > 0 && (
                    <>
                      <h4 style={{ marginTop: 20 }}>También la cubren con alguna línea (+{sel.extra.length})</h4>
                      <div className="bm-list">
                        {sel.extra.map((i) => (
                          <button key={i.id} className="bm-item" onClick={() => onOpen(i.id)}>
                            <span className="dot" style={{ '--c': INST_MAP[i.institucion].color }} />
                            {i.nombre}
                            <span className="tag" style={{ marginLeft: 6 }}>
                              principal: {ETAPA_MAP[i.etapa].corto}
                            </span>
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>
                <div>
                  <h4>Referencia experta ({refs.length})</h4>
                  {refs.length ? (
                    <div className="refs">
                      {refs.map((r) => {
                        const target = r.instrumentos.find((id) => INSTR_MAP[id])
                        return target ? (
                          <button key={r.id} className="ref" title={r.descripcion} onClick={() => onOpen(target)}>
                            {r.nombre}
                          </button>
                        ) : (
                          <span key={r.id} className="ref" title={`${r.descripcion} · Sin ficha vinculada en el catálogo`}>
                            {r.nombre}
                          </span>
                        )
                      })}
                    </div>
                  ) : (
                    <p className="hint">Sin referencias expertas asociadas a esta etapa.</p>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <Reveal className="transversal-note">
          <Icon name="compass" size={22} style={{ color: 'var(--teal)', flexShrink: 0 }} />
          <span>
            <b>{transversales.length} instrumentos transversales</b> acompañan varias etapas:{' '}
            {transversales.map((t) => t.nombre).join(', ')}.
          </span>
          <button className="btn" onClick={() => onExplore({ etapa: 'transversal' })}>
            Ver transversales
          </button>
        </Reveal>
      </div>
    </section>
  )
}
