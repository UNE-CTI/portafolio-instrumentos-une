import { useState } from 'react'
import { motion } from 'framer-motion'
import Icon from './Icon'
import { Counter, ease } from './motion'
import { INSTITUCIONES, NECESIDADES, TOTALES } from '../lib/data'


const item = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease } },
}

export default function Hero({ onSearch, onNeed }) {
  const [q, setQ] = useState('')
  const submit = (e) => {
    e.preventDefault()
    onSearch(q)
  }
  return (
    <section className="hero" id="inicio">
      <div className="hero-bg" />
      <motion.div
        className="hero-glow"
        animate={{ x: [0, -30, 0], y: [0, 20, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="hero-glow b"
        animate={{ x: [0, 40, 0], y: [0, -24, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      <div className="wrap hero-grid">
        <motion.div initial="hidden" animate="show" transition={{ staggerChildren: 0.09 }}>
          <motion.span variants={item} className="kicker">
            Portafolio de instrumentos de apoyo empresarial
          </motion.span>
          <motion.h1 variants={item}>
            El universo de apoyo empresarial de Uruguay, <em>en un solo mapa.</em>
          </motion.h1>
          <motion.p variants={item} className="lede">
            Una vista integrada de los instrumentos públicos de financiamiento, asistencia técnica, innovación y acceso a
            mercados, clasificados por etapa, mecanismo y tipo de apoyo. Para empresas, organizaciones intermedias e
            instituciones que diseñan instrumentos y necesitan conocer la oferta existente.
          </motion.p>
          <motion.form variants={item} className="searchbox" onSubmit={submit} role="search">
            <Icon name="search" size={20} />
            <label htmlFor="hero-q" className="sr-only">
              Buscar instrumentos
            </label>
            <input
              id="hero-q"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar por tema, apoyo o institución: exportación, certificación, crédito…"
              autoComplete="off"
            />
            <motion.button className="btn btn-primary" type="submit" whileTap={{ scale: 0.97 }}>
              <motion.span
                className="shimmer"
                initial={{ x: '-100%' }}
                animate={{ x: '100%' }}
                transition={{ duration: 2.4, repeat: Infinity, repeatDelay: 2.2, ease: 'easeInOut' }}
              />
              Buscar
              <Icon name="arrow" size={16} />
            </motion.button>
          </motion.form>
          <motion.div variants={item} className="chips">
            <span className="chips-label">Explorar por necesidad:</span>
            {NECESIDADES.slice(0, 6).map((n) => (
              <motion.button key={n.id} className="chip" onClick={() => onNeed(n.id)} whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }}>
                <Icon name={n.icon} size={15} />
                {n.label}
              </motion.button>
            ))}
          </motion.div>
        </motion.div>

        <motion.div
          className="kpis"
          initial="hidden"
          animate="show"
          transition={{ staggerChildren: 0.08, delayChildren: 0.25 }}
        >
          <motion.div variants={item} className="kpi featured">
            <strong>
              <Counter value={TOTALES.instrumentos} />
            </strong>
            <span>instrumentos de apoyo</span>
            <small>dirigidos a empresas y unidades productivas</small>
          </motion.div>
          <motion.div variants={item} className="kpi">
            <span className="bar" style={{ background: 'var(--teal)' }} />
            <strong>
              <Counter value={TOTALES.lineas} />
            </strong>
            <span>líneas de apoyo</span>
            <small>modalidades concretas dentro de cada instrumento</small>
          </motion.div>
          <motion.div variants={item} className="kpi">
            <span className="bar" style={{ background: 'var(--accent)' }} />
            <strong>
              <Counter value={TOTALES.instituciones} />
            </strong>
            <span>instituciones</span>
            <small>agencias, ministerios e institutos</small>
          </motion.div>
          <motion.div variants={item} className="kpi">
            <span className="bar" style={{ background: 'var(--ochre)' }} />
            <strong>
              <Counter value={TOTALES.ventanilla} />
            </strong>
            <span>con ventanilla permanente</span>
            <small>admiten solicitudes en cualquier momento</small>
          </motion.div>
          <motion.div variants={item} className="inst-strip">
            {INSTITUCIONES.map((i) => (
              <span key={i.id} title={i.nombre}>
                <span className="dot" style={{ '--c': i.color }} />
                {i.sigla}
              </span>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
