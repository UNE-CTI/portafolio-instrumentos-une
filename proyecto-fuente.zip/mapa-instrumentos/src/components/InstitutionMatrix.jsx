import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { Counter, Tabs, ease } from './motion'
import { ETAPA_MAP, ETAPAS, INST_MAP, INSTITUCIONES, INSTRUMENTOS } from '../lib/data'

const MODOS = [
  { id: 'cobertura', label: 'Cobertura' },
  { id: 'principal', label: 'Etapa principal' },
]
const NOTA = {
  cobertura: 'Instrumentos con la etapa como principal o con alguna línea que la cubre. Un instrumento puede aparecer en varias columnas.',
  principal: 'Cada instrumento se cuenta una sola vez, en su etapa principal.',
}
const VISIBLES = 10
// guiones opcionales para columnas angostas
const HEAD = { consolidacion: 'Consoli\u00ADdación', internacional: 'Internacio\u00ADnalización', transversal: 'Trans\u00ADversal' }

const enEtapa = (ins, etapa, modo) =>
  etapa === 'transversal'
    ? ins.etapa === 'transversal' || ins.transversal.length > 0
    : modo === 'principal'
      ? ins.etapa === etapa
      : ins.cobertura.includes(etapa) // incluye la etapa principal

export const seleccionar = (sel, modo) =>
  INSTRUMENTOS.filter((i) => (!sel.i || i.institucion === sel.i) && (!sel.e || enEtapa(i, sel.e, modo))).sort((a, b) =>
    a.nombre.localeCompare(b.nombre, 'es'),
  )

/** Matriz de burbujas institución × etapa: el área codifica la cantidad; el detalle aparece al seleccionar. */
export default function InstitutionMatrix({ modo, setModo, sel, setSel, onExplore, onOpen }) {
  const [hover, setHover] = useState(null)

  const matriz = useMemo(
    () =>
      INSTITUCIONES.map((inst) => {
        const own = INSTRUMENTOS.filter((i) => i.institucion === inst.id)
        return { inst, total: own.length, cells: ETAPAS.map((e) => own.filter((i) => enEtapa(i, e.id, modo)).length) }
      }),
    [modo],
  )
  const max = Math.max(...matriz.flatMap((r) => r.cells))
  const diam = (n) => (n ? 12 + 30 * Math.sqrt(n / max) : 5)

  const lista = useMemo(() => seleccionar(sel, modo), [sel, modo])
  const base = sel.i ? INSTRUMENTOS.filter((x) => x.institucion === sel.i).length : INSTRUMENTOS.length
  const vacio = !sel.i && !sel.e
  const titulo = [sel.i && INST_MAP[sel.i].sigla, sel.e && ETAPA_MAP[sel.e].nombre].filter(Boolean).join(' · ') || 'Todo el portafolio'
  const contexto = sel.i && sel.e
    ? `de los ${base} instrumentos de ${INST_MAP[sel.i].sigla}`
    : sel.i
      ? `de ${INST_MAP[sel.i].nombre}`
      : sel.e
        ? `de los ${INSTRUMENTOS.length} instrumentos del portafolio`
        : ''

  const activo = (ri, ci) => !hover || hover.r === ri || hover.c === ci
  const toggle = (next) => setSel((s) => (s.i === next.i && s.e === next.e ? { i: null, e: null } : next))

  return (
    <div className="bm">
      <div className="card-head">
        <div>
          <h3>Instituciones por etapa</h3>
          <p>{NOTA[modo]}</p>
        </div>
        <Tabs id="bm" items={MODOS} value={modo} onChange={setModo} label="Criterio de conteo" />
      </div>

      <div className="bm-scroll">
        <div className="bm-grid" role="grid" aria-label="Instrumentos por institución y etapa" onMouseLeave={() => setHover(null)}>
          <span />
          {ETAPAS.map((e, ci) => (
            <button
              key={e.id}
              className={`bm-col ${sel.e === e.id && !sel.i ? 'on' : ''} ${hover && hover.c === ci ? 'hot' : ''}`}
              onClick={() => toggle({ i: null, e: e.id })}
              onMouseEnter={() => setHover({ c: ci })}
              title={`Ver todos los instrumentos en ${e.nombre}`}
            >
              {e.orden < 6 && <i className="num">{e.orden}</i>}
              {HEAD[e.id] || e.corto}
            </button>
          ))}
          {matriz.map((r, ri) => (
            <div key={r.inst.id} role="row" style={{ display: 'contents' }}>
              <button
                className={`bm-row ${sel.i === r.inst.id && !sel.e ? 'on' : ''} ${hover && hover.r === ri ? 'hot' : ''}`}
                onClick={() => toggle({ i: r.inst.id, e: null })}
                onMouseEnter={() => setHover({ r: ri })}
                title={r.inst.nombre}
              >
                <span className="dot" style={{ '--c': r.inst.color }} />
                <b>{r.inst.sigla}</b>
                <small className="num">{r.total}</small>
              </button>
              {r.cells.map((n, ci) => {
                const e = ETAPAS[ci]
                const on = sel.i === r.inst.id && sel.e === e.id
                const d = diam(n)
                return (
                  <button
                    key={e.id}
                    role="gridcell"
                    className={`bm-cell ${on ? 'on' : ''}`}
                    disabled={!n}
                    aria-pressed={on}
                    aria-label={`${r.inst.sigla}, ${e.nombre}: ${n} instrumentos`}
                    onMouseEnter={() => setHover({ r: ri, c: ci })}
                    onFocus={() => setHover({ r: ri, c: ci })}
                    onClick={() => toggle({ i: r.inst.id, e: e.id })}
                  >
                    <motion.span
                      className={`bm-dot ${n ? '' : 'bm-none'}`}
                      style={{ width: d, height: d }}
                      initial={false}
                      animate={{ opacity: activo(ri, ci) ? 1 : 0.22 }}
                      transition={{ duration: 0.2 }}
                    />
                    {hover && hover.r === ri && hover.c === ci && n > 0 && (
                      <motion.span className="bm-val num" initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>
                        {n}
                      </motion.span>
                    )}
                  </button>
                )
              })}
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={`${sel.i}-${sel.e}-${modo}`}
          className="bm-detail"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.25, ease }}
        >
          <div className="bm-detail-head">
            <div>
              <span className="bm-detail-title">{titulo}</span>
              <span className="bm-detail-n">
                <b className="num">
                  <Counter value={lista.length} duration={0.5} />
                </b>{' '}
                {lista.length === 1 ? 'instrumento' : 'instrumentos'} {contexto}
              </span>
            </div>
            <button
              className="btn"
              onClick={() =>
                onExplore({ ...(sel.i ? { institucion: sel.i } : {}), ...(sel.e ? { etapa: sel.e } : {}) })
              }
            >
              Abrir en el explorador <Icon name="arrow" size={15} />
            </button>
          </div>
          {vacio ? (
            <p className="hint">Seleccione una burbuja, una institución o una etapa para ver qué instrumentos la componen.</p>
          ) : (
          <div className="bm-list">
            {lista.slice(0, VISIBLES).map((ins, k) => (
              <motion.button
                key={ins.id}
                className="bm-item"
                onClick={() => onOpen(ins.id)}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, delay: k * 0.025 }}
              >
                {!sel.i && <span className="dot" style={{ '--c': INST_MAP[ins.institucion].color }} />}
                {ins.nombre}
              </motion.button>
            ))}
            {lista.length > VISIBLES && (
              <span className="bm-more">y {lista.length - VISIBLES} más en el explorador</span>
            )}
          </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
