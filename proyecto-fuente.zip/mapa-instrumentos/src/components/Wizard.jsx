import { useMemo, useState } from 'react'
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion'
import Icon from './Icon'
import { Reveal, ease } from './motion'
import { BENEFICIARIOS, ETAPA_TEXTO, INST_MAP, INSTRUMENTOS, NECESIDADES, STAGES5, lineaCumpleNecesidad } from '../lib/data'

const STEPS = ['Etapa', 'Necesidad', 'Quién solicita']

export default function Wizard({ onOpen, onExplore }) {
  const [step, setStep] = useState(0)
  const [dir, setDir] = useState(1)
  const [sel, setSel] = useState({ etapa: '', necesidad: '', benef: '' })

  const go = (n) => {
    setDir(n > step ? 1 : -1)
    setStep(n)
  }
  const pick = (k, v) => {
    setSel((s) => ({ ...s, [k]: s[k] === v ? '' : v }))
    if (step < 2) setTimeout(() => go(step + 1), 220)
  }

  const results = useMemo(() => {
    const nec = NECESIDADES.find((n) => n.id === sel.necesidad)
    const ben = BENEFICIARIOS.find((b) => b.id === sel.benef)
    // La necesidad y el solicitante filtran; la etapa ordena (principal > cobertura > otra etapa).
    return INSTRUMENTOS.map((ins) => {
      let ls = ins.lineas
      if (ben) ls = ls.filter(ben.test)
      if (nec) ls = ls.filter((l) => lineaCumpleNecesidad(l, nec))
      if (!ls.length) return null
      const main = !!sel.etapa && ins.etapa === sel.etapa
      const cubre = !!sel.etapa && (ls.some((l) => l.etapas.includes(sel.etapa)) || ins.etapa === 'transversal')
      const stagePts = !sel.etapa ? 2 : main ? 2 : cubre ? 1 : 0
      const nivel = Math.max(1, stagePts + (nec || ben ? 1 : 0))
      const score = stagePts * 10 + ls.length
      return { ins, ls, main, cubre, nivel, score }
    })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score || a.ins.nombre.localeCompare(b.ins.nombre))
  }, [sel])

  const answered = [sel.etapa, sel.necesidad, sel.benef].filter(Boolean).length
  const variants = {
    enter: (d) => ({ x: d * 40, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d) => ({ x: d * -40, opacity: 0 }),
  }

  return (
    <section className="section" id="asistente">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <span className="kicker">Consulta guiada</span>
            <h2>Oferta disponible para un perfil</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>
              Al combinar etapa, necesidad y tipo de solicitante, los instrumentos se ordenan por afinidad. Sirve para
              orientar a una empresa o para revisar cuánta oferta existe para un perfil determinado. Cada paso es opcional.
            </p>
          </Reveal>
        </div>

        <div className="wizard">
          <Reveal className="card wizard-card">
            <div className="wizard-steps" role="list">
              {STEPS.map((s, i) => (
                <button key={s} role="listitem" className="wizard-step" aria-current={step === i ? 'step' : undefined} onClick={() => go(i)}>
                  Paso {i + 1}
                  <b>{s}</b>
                  {step === i && <motion.span layoutId="wiz-line" className="wizard-step-line" />}
                </button>
              ))}
            </div>
            <div className="wizard-body">
              <AnimatePresence mode="wait" custom={dir} initial={false}>
                <motion.div
                  key={step}
                  custom={dir}
                  variants={variants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.3, ease }}
                >
                  {step === 0 && (
                    <>
                      <h3>Etapa del proyecto</h3>
                      <p>Función del proyecto a apoyar, independiente de la antigüedad de la empresa.</p>
                      <div className="options">
                        {STAGES5.map((e) => (
                          <button key={e.id} className="option" aria-pressed={sel.etapa === e.id} onClick={() => pick('etapa', e.id)} title={ETAPA_TEXTO[e.id]}>
                            <span className="reco-rank" style={{ width: 28, height: 28, fontSize: 12 }}>
                              {e.orden}
                            </span>
                            {e.nombre}
                          </button>
                        ))}
                        <button className="option" aria-pressed={false} onClick={() => { setSel((s) => ({ ...s, etapa: '' })); go(1) }}>
                          <Icon name="help" />
                          Sin especificar
                        </button>
                      </div>
                    </>
                  )}
                  {step === 1 && (
                    <>
                      <h3>Necesidad principal</h3>
                      <p>Capacidad empresarial que el apoyo busca fortalecer.</p>
                      <div className="options">
                        {NECESIDADES.map((n) => (
                          <button key={n.id} className="option" aria-pressed={sel.necesidad === n.id} onClick={() => pick('necesidad', n.id)}>
                            <Icon name={n.icon} />
                            {n.label}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                  {step === 2 && (
                    <>
                      <h3>Tipo de solicitante</h3>
                      <p>Algunos instrumentos se dirigen a públicos específicos.</p>
                      <div className="options">
                        {BENEFICIARIOS.map((b) => (
                          <button key={b.id} className="option wide" aria-pressed={sel.benef === b.id} onClick={() => pick('benef', b.id)}>
                            <Icon name={b.id === 'persona' ? 'user' : 'building'} />
                            {b.label}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
            <div className="wizard-foot">
              <button className="btn" onClick={() => go(Math.max(0, step - 1))} disabled={step === 0} style={{ opacity: step === 0 ? 0.5 : 1 }}>
                <Icon name="back" size={16} />
                Anterior
              </button>
              {answered > 0 && (
                <button className="linkbtn" onClick={() => { setSel({ etapa: '', necesidad: '', benef: '' }); go(0) }}>
                  Reiniciar
                </button>
              )}
              {step < 2 ? (
                <button className="btn" onClick={() => go(step + 1)}>
                  Siguiente
                  <Icon name="arrow" size={16} />
                </button>
              ) : (
                <button className="btn btn-primary" onClick={() => onExplore({ etapa: sel.etapa, necesidad: sel.necesidad })}>
                  Abrir en el explorador
                  <Icon name="arrow" size={16} />
                </button>
              )}
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="results-head">
              <h3>{answered ? 'Instrumentos afines' : 'Sin criterios seleccionados'}</h3>
              <span>
                {answered ? (
                  <>
                    <b className="num" style={{ color: 'var(--ink)' }}>
                      {results.length}
                    </b>{' '}
                    coincidencias
                  </>
                ) : (
                  `${INSTRUMENTOS.length} instrumentos disponibles`
                )}
              </span>
            </div>
            {answered === 0 ? (
              <div className="empty">
                <b>Los instrumentos afines aparecerán aquí</b>
                Seleccione al menos una etapa, una necesidad o un tipo de solicitante.
              </div>
            ) : results.length === 0 ? (
              <div className="empty">
                <b>Sin coincidencias con esa combinación</b>
                No hay oferta registrada para esa combinación de necesidad y solicitante.
              </div>
            ) : (
              <LayoutGroup>
                <motion.div className="reco-list" layout>
                  <AnimatePresence initial={false}>
                    {results.slice(0, 7).map((r, i) => {
                      const inst = INST_MAP[r.ins.institucion]
                      const nivel = r.nivel
                      return (
                        <motion.button
                          key={r.ins.id}
                          layout
                          className="reco"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.97 }}
                          transition={{ duration: 0.3, ease }}
                          onClick={() => onOpen(r.ins.id)}
                        >
                          <span className="reco-rank num">{i + 1}</span>
                          <span>
                            <h4>{r.ins.nombre}</h4>
                            <p>
                              <span className="dot" style={{ '--c': inst.color }} />
                              {inst.sigla} · {r.ls.length} {r.ls.length === 1 ? 'línea aplicable' : 'líneas aplicables'}
                              {r.main ? ' · etapa principal' : r.cubre ? ' · cubre la etapa' : sel.etapa ? ' · otra etapa' : ''}
                            </p>
                          </span>
                          <span className="fit" title={`Afinidad ${nivel} de 3`} aria-label={`Afinidad ${nivel} de 3`}>
                            {[0, 1, 2].map((k) => (
                              <i key={k} className={k < nivel ? 'on' : ''} />
                            ))}
                          </span>
                        </motion.button>
                      )
                    })}
                  </AnimatePresence>
                </motion.div>
              </LayoutGroup>
            )}
            {results.length > 7 && answered > 0 && (
              <div className="more">
                <button className="linkbtn" onClick={() => onExplore({ necesidad: sel.necesidad })}>
                  Ver las {results.length} coincidencias en el explorador
                </button>
              </div>
            )}
          </Reveal>
        </div>
      </div>
    </section>
  )
}
