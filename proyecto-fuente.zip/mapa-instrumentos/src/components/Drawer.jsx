import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { ease } from './motion'
import { ETAPAS, INST_MAP, INSTR_MAP, STAGES5, palabrasClave } from '../lib/data'

function Linea({ l, ins, open, onToggle }) {
  return (
    <div className="line-card">
      <button onClick={onToggle} aria-expanded={open}>
        <b>{l.linea}</b>
        <span className="tag">{l.mecanismo.split(' / ')[0]}</span>
        <motion.span className="chev" animate={{ rotate: open ? 180 : 0 }}>
          <Icon name="chev" />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease }}
            style={{ overflow: 'hidden' }}
          >
            <div className="line-body">
              <p>{l.descripcion}</p>
              <dl className="dl">
                <dt>Para quién</dt>
                <dd>{l.publico}</dd>
                <dt>Etapas que cubre</dt>
                <dd>
                  {l.etapas.length ? l.etapas.map((e) => ETAPAS.find((x) => x.id === e).nombre).join(' · ') : 'Transversal'}
                  {l.transversal && <> · eje: {l.transversal}</>}
                  {l.fundamentoExperto && <span style={{ display: 'block', color: 'var(--muted)', fontSize: 12 }}>{l.fundamentoExperto}</span>}
                  {ins.etapa !== 'transversal' && l.etapa !== ins.etapa && (
                    <span className="tag ochre" style={{ marginLeft: 6 }}>
                      difiere de la etapa del instrumento
                    </span>
                  )}
                </dd>
                <dt>Mecanismo</dt>
                <dd>
                  {l.mecanismo}
                  {l.mecanismosComp?.length > 0 && (
                    <span style={{ color: 'var(--muted)' }}> · complementario: {l.mecanismosComp.join(' · ')}</span>
                  )}
                </dd>
                <dt>Acceso</dt>
                <dd>
                  {l.modalidad} · {l.vigencia}
                </dd>
                <dt>Apoyos concretos</dt>
                <dd className="tags">
                  {l.apoyos.map((a) => (
                    <span key={a.c} className={`tag ${a.ajuste ? 'aj' : ''}`} title={a.ajuste ? 'Agregado con sustento en las bases' : undefined}>
                      {a.t}
                    </span>
                  ))}
                </dd>
                <dt>Capacidades</dt>
                <dd className="tags">
                  {l.capacidades.map((a) => (
                    <span key={a.c} className={`tag teal ${a.ajuste ? 'aj' : ''}`} title={a.ajuste ? 'Agregado con sustento en las bases' : undefined}>
                      {a.t}
                    </span>
                  ))}
                </dd>
                {l.referencia && l.referencia !== 'Sin correspondencia explícita' && (
                  <>
                    <dt>Referencia experta</dt>
                    <dd>{l.referencia}</dd>
                  </>
                )}
                <dt>Fundamento de etapa</dt>
                <dd style={{ color: 'var(--ink-2)' }}>{l.fundamento}</dd>
                <dt>Fuente</dt>
                <dd style={{ color: 'var(--ink-2)' }}>
                  {l.cobertura} · confianza {l.confianza?.toLowerCase()}
                </dd>
              </dl>
              {l.ajustes?.length > 0 && (
                <div className="ajustes">
                  <b>Ajustes con sustento en las bases</b>
                  {l.ajustes.map((a, i) => (
                    <div key={i} className="ajuste">
                      <span className="tag aj">{a.valor}</span>
                      <p>{a.fundamento}</p>
                      <blockquote>“{a.cita}”</blockquote>
                    </div>
                  ))}
                </div>
              )}
              {l.notaFuente && <p className="notice">Fuente a revisar: {l.notaFuente}</p>}
              <div className="links">
                {l.urlFicha && (
                  <a className="btn btn-primary" href={l.urlFicha} target="_blank" rel="noopener noreferrer">
                    Sitio oficial <Icon name="ext" size={15} />
                  </a>
                )}
                {l.urlBases && l.urlBases !== l.urlFicha && (
                  <a className="btn" href={l.urlBases} target="_blank" rel="noopener noreferrer">
                    <Icon name="doc" size={15} /> Bases o documento
                  </a>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function Drawer({ id, onClose }) {
  const ins = id ? INSTR_MAP[id] : null
  const [openLine, setOpenLine] = useState(null)
  const closeRef = useRef(null)

  useEffect(() => {
    if (!ins) return
    setOpenLine(ins.lineas[0].id)
    const prev = document.activeElement
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    setTimeout(() => closeRef.current?.focus(), 50)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
      prev?.focus?.()
    }
  }, [ins, onClose])

  const inst = ins && INST_MAP[ins.institucion]
  const kw = ins ? palabrasClave(ins.id) : null
  return (
    <AnimatePresence>
      {ins && (
        <>
          <motion.div
            key="bd"
            className="backdrop"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          <motion.aside
            key={ins.id}
            className="drawer"
            role="dialog"
            aria-modal="true"
            aria-labelledby="drawer-title"
            style={{ '--inst': inst.color }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 320, damping: 36 }}
          >
            <div className="drawer-head">
              <div className="row">
                <span>
                  <span className="dot" style={{ '--c': inst.color }} />
                  {inst.sigla} · {inst.nombre}
                </span>
                <button ref={closeRef} className="close" onClick={onClose} aria-label="Cerrar ficha">
                  <Icon name="x" />
                </button>
              </div>
              <motion.h2 id="drawer-title" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
                {ins.nombre}
              </motion.h2>
              <p className="sub">
                {ins.lineas.length} {ins.lineas.length === 1 ? 'línea de apoyo' : 'líneas de apoyo'} · {inst.rol}
              </p>
            </div>
            <motion.div
              className="drawer-body"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.15, duration: 0.3 }}
            >
              <div className="drawer-section">
                <h4>Etapas</h4>
                <div className="stage-chips">
                  {STAGES5.map((e) => (
                    <span
                      key={e.id}
                      className={`stage-chip ${ins.etapa === e.id ? 'on main' : ins.cobertura.includes(e.id) ? 'on' : ''}`}
                    >
                      {e.orden}. {e.nombre}
                    </span>
                  ))}
                  {ins.etapa === 'transversal' && <span className="stage-chip on main">Transversal</span>}
                </div>
                {ins.criterio && (
                  <div className="criterio">
                    <span className={`tag ${ins.criterio.metodo.startsWith('Referencia') ? '' : 'ochre'}`}>{ins.criterio.metodo}</span>
                    <b>{ins.criterio.referencia}</b>
                    <p>{ins.criterio.fundamento}</p>
                  </div>
                )}
              </div>
              <div className="drawer-section">
                <h4>
                  Palabras clave · {kw.origen === 'bases' ? `según bases oficiales (${ins.fuentesLeidas} documentos)` : 'según el portafolio'}
                </h4>
                <div className="kw-row">
                  {kw.palabras.map((w) => (
                    <span key={w} className="kw strong">
                      {w}
                    </span>
                  ))}
                </div>
              </div>
              <div className="drawer-section">
                <h4>Líneas de apoyo</h4>
                {ins.lineas.map((l) => (
                  <Linea
                    key={l.id}
                    l={l}
                    ins={ins}
                    open={openLine === l.id}
                    onToggle={() => setOpenLine(openLine === l.id ? null : l.id)}
                  />
                ))}
              </div>
              <p className="notice">
                La clasificación orienta la búsqueda: no acredita que haya una convocatoria abierta ni garantiza elegibilidad.
                Requisitos, plazos y montos deben confirmarse en las bases vigentes de {inst.sigla}.
              </p>
            </motion.div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  )
}
