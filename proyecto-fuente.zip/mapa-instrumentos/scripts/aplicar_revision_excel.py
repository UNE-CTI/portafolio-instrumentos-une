"""Aplica las decisiones de la revisión con bases al Excel de insumos.

Entrada:  data-fuente/Clasificacion_etapas_B20_ajustada_palabras_clave.xlsx (de extraer_bases.py + revisar_clasificacion.py)
          data-fuente/decisiones_revision_bases.json
Salida:   data-fuente/Clasificacion_etapas_B20_revisada_bases.xlsx

En la hoja "Líneas originales B20" se agregan los apoyos, capacidades y mecanismos complementarios aceptados;
cada celda modificada queda resaltada y con un comentario (fundamento y cita de la base).
"""
import json
from pathlib import Path

import openpyxl
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill

RAIZ = Path(__file__).resolve().parent.parent
FUENTE = RAIZ / "data-fuente" / "Clasificacion_etapas_B20_ajustada_palabras_clave.xlsx"
DESTINO = RAIZ / "data-fuente" / "Clasificacion_etapas_B20_revisada_bases.xlsx"
RESALTE = PatternFill("solid", fgColor="F6E7C8")
CABECERA = PatternFill("solid", fgColor="27428C")

# Alertas "sin respaldo" y de vigencia revisadas: se mantiene la clasificación, con este fundamento
MANTENER = {
    ("LIN-EFC3913B", "Transferencia"): "Se mantiene: “ANDE aportará hasta el 80% del valor total con un monto máximo de $650.000”.",
    ("LIN-15384976", "A10"): "Se mantiene: el emprendimiento postula con una Institución Patrocinadora (IPE) que lo acompaña (Anexo 1).",
    ("LIN-A1317422", "Transferencia"): "Se mantiene: “Las soluciones seleccionadas podrán recibir financiamiento total o parcial… hasta USD 10.000”.",
    ("LIN-D0C9246B", "A16"): "Se mantiene: “una semana de inmersión en el ecosistema emprendedor local… conexiones entre startups, inversores y líderes”.",
    ("LIN-0E7B971E", "C2"): "Se mantiene: el programa usa la herramienta informática de mejora y aprendizaje HIMA.",
    ("LIN-FC0EBA80", "Transferencia"): "Se mantiene: el FPTA financia proyectos de terceros; la convocatoria 2026 dispone hasta US$ 3.700.000.",
    ("LIN-2F251984", "A15"): "Se mantiene: la URL no corresponde al instrumento (ver Fuentes a corregir); la base no refuta la clasificación.",
    ("LIN-2F251984", "C11"): "Se mantiene: la URL no corresponde al instrumento (ver Fuentes a corregir); la base no refuta la clasificación.",
    ("LIN-F190A5DC", "Premio"): "Se mantiene: el sello es un reconocimiento otorgado según el manual de requisitos LATU–UEU.",
    ("LIN-3C782B1C", "A14"): "Se mantiene: los ahorros de las medidas estandarizadas son “certificados por el MIEM”.",
    ("LIN-VIN", "A10"): "Se mantiene: “Acompañamiento de una Institución Patrocinadora de Emprendimientos (IPE-VIN) en las etapas de diseño, formulación y ejecución del proyecto”.",
    ("LIN-PAIE", "A10"): "Se mantiene: el PAIE “es un acompañamiento global para la persona emprendedora desde el momento de la idea hasta la puesta en marcha”.",
}


def main():
    dec = json.loads((RAIZ / "data-fuente" / "decisiones_revision_bases.json").read_text(encoding="utf-8"))
    wb = openpyxl.load_workbook(FUENTE)
    ws = wb["Líneas originales B20"]
    cab = [c.value for c in ws[1]]
    col = {n: cab.index(n) + 1 for n in cab}
    filas = {ws.cell(r, 1).value: r for r in range(2, ws.max_row + 1) if ws.cell(r, 1).value}

    # etiquetas de códigos a partir del propio Excel
    etiquetas, mcod = {}, {}
    for r in filas.values():
        for campo in ("apoyos_concretos", "capacidades_empresariales"):
            for parte in (ws.cell(r, col[campo]).value or "").split(";"):
                parte = parte.strip()
                if parte:
                    etiquetas[parte.split(" ", 1)[0]] = parte
        mcod[ws.cell(r, col["mecanismo_principal"]).value] = ws.cell(r, col["mecanismo_codigo"]).value

    def agregar(r, campo_cod, campo_txt, codigo, nota):
        cod = ws.cell(r, col[campo_cod])
        txt = ws.cell(r, col[campo_txt])
        cod.value = ";".join(filter(None, [(cod.value or "").strip(), codigo]))
        txt.value = "; ".join(filter(None, [(txt.value or "").strip(), etiquetas[codigo]]))
        for c in (cod, txt):
            c.fill = RESALTE
            c.comment = Comment(nota, "Revisión con bases")

    nueva = ws.max_column + 1
    ws.cell(1, nueva, "Ajustes con sustento en bases").font = Font(bold=True)
    ws.cell(1, nueva + 1, "Fuente a revisar").font = Font(bold=True)
    resumen = {}
    for a in dec["aceptadas"]:
        if a["linea_id"] not in filas:  # instrumentos incorporados: se agregan en aplicar_criterio_experto.py
            continue
        r = filas[a["linea_id"]]
        nota = f"{a['fundamento']}\n\nBase: “{a['cita']}”"
        if a["dimension"] == "apoyo":
            agregar(r, "apoyos_códigos", "apoyos_concretos", a["valor"], nota)
            etiqueta = etiquetas[a["valor"]]
        elif a["dimension"] == "capacidad":
            agregar(r, "capacidades_códigos", "capacidades_empresariales", a["valor"], nota)
            etiqueta = etiquetas[a["valor"]]
        else:
            c = ws.cell(r, col["mecanismos_complementarios"])
            etiqueta = f"{mcod.get(a['valor'], '')} {a['valor']}".strip()
            c.value = "; ".join(filter(None, [(c.value or "").strip(), etiqueta]))
            c.fill = RESALTE
            c.comment = Comment(nota, "Revisión con bases")
        resumen.setdefault(r, []).append(f"+ {etiqueta}")
    for r, cambios in resumen.items():
        ws.cell(r, nueva, "; ".join(cambios)).fill = RESALTE
    for f in dec["fuentes_a_corregir"]:
        if f["linea_id"] in filas:
            ws.cell(filas[f["linea_id"]], nueva + 1, f["nota"])

    # decisiones en la hoja de alertas
    h = wb["Revisión con bases"]
    hc = [c.value for c in h[1]]
    ci = {n: hc.index(n) + 1 for n in hc}
    acept = {(a["linea_id"], a["valor"]): a for a in dec["aceptadas"]}
    rech = {(a["linea_id"], a["valor"]): a for a in dec["rechazadas"]}
    fuentes = {f["linea_id"]: f["nota"] for f in dec["fuentes_a_corregir"]}
    for r in range(2, h.max_row + 1):
        lid, tipo, valor = h.cell(r, ci["linea_id"]).value, h.cell(r, ci["Tipo de alerta"]).value, h.cell(r, ci["Valor detectado"]).value
        codigo = valor.split(" ")[0] if valor and valor[:1] in "AC" and valor[1:2].isdigit() else valor
        if (lid, codigo) in acept:
            d, c = "Aceptada", f"{acept[(lid, codigo)]['fundamento']} Base: “{acept[(lid, codigo)]['cita']}”"
        elif (lid, codigo) in rech:
            d, c = "Descartada", rech[(lid, codigo)]["fundamento"]
        elif tipo == "Sin respaldo en bases":
            clave = next((k for k in MANTENER if k[0] == lid and valor.startswith(k[1])), None)
            d, c = "Se mantiene", MANTENER.get(clave, "Revisar manualmente.")
        elif tipo == "Vigencia":
            d = "Sin cambio de clasificación"
            c = fuentes.get(lid, "La fuente consultada no menciona 2026: verificar si existe una edición vigente.")
        else:
            d, c = "Pendiente", ""
        h.cell(r, ci["Decisión"], d).font = Font(bold=True, color={"Aceptada": "1F7A4D", "Descartada": "9A3B32"}.get(d, "555555"))
        h.cell(r, ci["Comentario"], c)

    # hojas de resumen
    for nombre in ("Ajustes aplicados", "Fuentes a corregir"):
        if nombre in wb.sheetnames:
            del wb[nombre]
    lin = {l["id"]: (l["institucion"], l["instrumento"], l["linea"]) for l in
           json.loads((RAIZ / "src" / "data" / "portafolio.json").read_text(encoding="utf-8"))["lineas"]}
    aj = wb.create_sheet("Ajustes aplicados", 0)
    aj.append(["linea_id", "Institución", "Instrumento", "Línea", "Dimensión", "Valor agregado", "Fundamento", "Cita de la base"])
    for a in dec["aceptadas"]:
        v = etiquetas.get(a["valor"], {"A06": "A06 Beneficio o crédito fiscal"}.get(a["valor"], a["valor"]))
        aj.append([a["linea_id"], *lin[a["linea_id"]], a["dimension"], v, a["fundamento"], a["cita"]])
    fc = wb.create_sheet("Fuentes a corregir", 1)
    fc.append(["linea_id", "Institución", "Instrumento", "Línea", "Problema detectado"])
    for f in dec["fuentes_a_corregir"]:
        fc.append([f["linea_id"], *lin[f["linea_id"]], f["nota"]])
    for hoja, anchos in ((aj, [15, 12, 30, 34, 11, 40, 55, 80]), (fc, [15, 12, 30, 34, 90])):
        for c in hoja[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = CABECERA
        hoja.freeze_panes = "A2"
        for i, w in enumerate(anchos, 1):
            hoja.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
        for fila in hoja.iter_rows(min_row=2):
            for c in fila:
                c.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(DESTINO)
    print(f"{len(dec['aceptadas'])} ajustes aplicados · {DESTINO}")


if __name__ == "__main__":
    main()
