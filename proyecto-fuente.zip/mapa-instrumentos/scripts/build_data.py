"""Combina el portafolio revisado (data.js) y el Excel de clasificación B20 en src/data/portafolio.json.

- Portafolio (data.js): define el universo (74 instrumentos, 104 líneas), la etapa principal
  de cada instrumento, la modalidad de acceso, las URL oficiales, las instituciones y las
  referencias expertas por etapa.
- Excel B20: aporta la clasificación funcional por línea (etapas cubiertas, transversalidad,
  fundamento, referencia experta) y los campos de capacidades, apoyos y público.

Uso: python3 scripts/build_data.py data-fuente/portafolio_data_30_10_2026.js data-fuente/Clasificacion_etapas_B20_ajustada.xlsx
"""
import json
import re
import sys
from pathlib import Path

import openpyxl

ETAPAS = [
    ("ideacion", "Ideación y prueba"),
    ("id", "Investigación y desarrollo"),
    ("marcha", "Puesta en marcha"),
    ("consolidacion", "Consolidación y crecimiento"),
    ("internacional", "Internacionalización y escalamiento"),
]

INSTITUCIONES = {
    "ANDE": "Agencia Nacional de Desarrollo",
    "ANII": "Agencia Nacional de Investigación e Innovación",
    "MIEM": "Ministerio de Industria, Energía y Minería",
    "INACOOP": "Instituto Nacional del Cooperativismo",
    "URUGUAY XXI": "Uruguay XXI · Promoción de Inversiones, Exportaciones e Imagen País",
    "LATU": "Laboratorio Tecnológico del Uruguay",
    "INEFOP": "Instituto Nacional de Empleo y Formación Profesional",
    "INIA": "Instituto Nacional de Investigación Agropecuaria",
    "CEIBAL": "Centro Ceibal",
}
SIGLA = {"URUGUAY XXI": "Uruguay XXI"}

# Instrumentos retirados de la selección empresarial B20 (con sus líneas). El portafolio
# revisado queda en 74 instrumentos y 104 líneas.
EXCLUIDAS = {
    "LIN-104C859E": ("ANDE", "Formación en Asociatividad Empresarial",
                     "El destinatario directo es personal técnico de instituciones representativas, no las empresas."),
    "LIN-EE7EAA5C": ("ANII", "Vinculación con Expertos del Exterior",
                     "Las bases 2026 revisadas se orientan a instituciones de posgrado y prestadores de ASSE."),
}


def rows(ws):
    data = list(ws.iter_rows(values_only=True))
    head = data[0]
    return [dict(zip(head, r)) for r in data[1:] if r[0]]


def split_codes(text):
    """'A08 Asistencia técnica; A01 ANR' -> [{'c':'A08','t':'Asistencia técnica'}, ...]"""
    out = []
    for part in (text or "").split(";"):
        part = part.strip()
        m = re.match(r"^([A-Z]\d+)\s+(.*)$", part)
        if m:
            out.append({"c": m.group(1), "t": m.group(2)})
        elif part:
            out.append({"c": part, "t": part})
    return out


def beneficiario(publico):
    seg = [s.strip() for s in (publico or "").split(" · ") if s.strip()]
    sujeto = seg[0] if seg else "No especificado"
    tam = next((s for s in seg if re.search(r"Micro|Pequeña|Mediana|Grande", s) and ":" not in s), None)
    sector = next((s.split(":", 1)[1].strip() for s in seg if s.startswith("Sector:")), None)
    geo = next((s.split(":", 1)[1].strip() for s in seg if s.startswith("Geografía:")), None)
    return sujeto, tam, sector, geo


def load_portafolio(path):
    src = Path(path).read_text(encoding="utf-8")
    return json.loads(src[src.index("=") + 1:].strip().rstrip(";"))


def stage_id(label):
    label = re.sub(r"^\d+\.\s*", "", label or "")
    if label == "Transversal":
        return "transversal"
    return next(k for k, n in ETAPAS if n == label)


RAIZ_DATOS = Path(__file__).resolve().parent.parent / "data-fuente"


def main(portafolio_path, path):
    P = load_portafolio(portafolio_path)
    plineas = {l["id"]: l for l in P["lineas"]}
    wb = openpyxl.load_workbook(path, data_only=True)
    ajust = {r["linea_id"]: r for r in rows(wb["Líneas B20 ajustadas"])}
    orig = [r for r in rows(wb["Líneas originales B20"]) if r["linea_id"] in plineas]
    excluidas = [r for r in rows(wb["Líneas originales B20"]) if r["linea_id"] not in plineas]
    assert {r["linea_id"] for r in excluidas} == set(EXCLUIDAS), "El Excel difiere del portafolio en otras líneas"
    criterios = [
        {"aspecto": r["Aspecto"], "criterio": r["Criterio"]}
        for r in rows(wb["Criterios y límites"])
        if r["Aspecto"] not in ("Alcance", "Fecha")
    ]
    criterios.insert(0, {
        "aspecto": "Alcance",
        "criterio": "Universo empresarial revisado: 74 instrumentos y 104 líneas B20 (se incluyen públicos mixtos con B20).",
    })
    criterios.insert(1, {
        "aspecto": "Instrumentos retirados de la selección B20",
        "criterio": " ".join(f"{i} · {n}: {m}" for i, n, m in EXCLUIDAS.values()),
    })

    lineas = []
    for o in orig:
        a = ajust[o["linea_id"]]
        etapas = [k for k, label in ETAPAS if a.get(label) == 1]
        principal = next(k for k, label in ETAPAS if label == a["Etapa principal"])
        sujeto, tam, sector, geo = beneficiario(o["público_B20"])
        p = plineas[o["linea_id"]]
        lineas.append({
            "id": o["linea_id"],
            "inst": o["instrumento_id"],
            "institucion": o["institución"],
            "instrumento": o["instrumento"],
            "linea": o["línea"],
            "etapa": principal,
            "etapas": etapas,
            "transversal": a["Transversalidad"],
            "referencia": a["Referencia experta"],
            "fundamento": a["Fundamento del ajuste"],
            "descripcion": a["Descripción del apoyo en portafolio"] or o["detalle_del_apoyo"],
            "sintesis": o["síntesis_línea"],
            "publico": o["público_B20"],
            "sujeto": sujeto,
            "tamano": tam,
            "sector": sector,
            "geografia": geo,
            "vigencia": o["tipo_vigencia"] if o["tipo_vigencia"] != "ND" else "No determinada",
            "desafio": o["desafío_empresarial"],
            "finalidad": o["finalidad_principal"],
            "mecanismo": o["mecanismo_principal"],
            "mecanismosComp": [re.sub(r"^M\d+\s+", "", x.strip()) for x in (o["mecanismos_complementarios"] or "").split(";") if x.strip()],
            "capacidades": split_codes(o["capacidades_empresariales"]),
            "apoyos": split_codes(o["apoyos_concretos"]),
            "cobertura": o["cobertura_documental"],
            "confianza": o["confianza"],
            "revision": o["estado_revisión"],
            "modalidad": p["modalidad_acceso"] or "No determinada",
            "urlFicha": p["url_oficial"] or o["url_ficha"],
            "urlBases": p["url_bases"] or o["url_bases"],
            "observaciones": o["observaciones_fuente"],
        })

    instrumentos = {
        k: {"etapa": stage_id(v["etapa_principal"]), "justificacion": v.get("justificación_clasificación")}
        for k, v in P["instrumentos"].items()
    }

    # Instrumentos incorporados al portafolio (p. ej. SiGa Innovación, referencia experta sin instrumento)
    inc_path = RAIZ_DATOS / "instrumentos_incorporados.json"
    if inc_path.exists():
        inc = json.loads(inc_path.read_text(encoding="utf-8"))
        lineas.extend(inc["lineas"])
        instrumentos.update(inc["instrumentos"])
        for k, v in inc.get("instituciones_extra", {}).items():
            P["agencias"].append({**v, "nombre": k})

    # Criterio experto: prevalece la etapa de la referencia experta; el resto se asigna por analogía
    exp_path = RAIZ_DATOS / "criterio_experto.json"
    if exp_path.exists():
        exp = json.loads(exp_path.read_text(encoding="utf-8"))
        nombre_id = {l["instrumento"]: l["inst"] for l in lineas}
        for ref in P["referencia_etapas"]:
            for k in ref["instrumentos_ids"]:
                if k in instrumentos:
                    instrumentos[k].update(etapa=stage_id(ref["etapa"]), criterio={
                        "metodo": "Referencia experta directa", "referencia": ref["nombre"],
                        "fundamento": ref["descripcion"]})
        refs_por_nombre = {ref["nombre"]: ref for ref in P["referencia_etapas"]}
        for k, v in instrumentos.items():
            if v.get("referencia") in refs_por_nombre:
                ref = refs_por_nombre[v["referencia"]]
                v.update(etapa=stage_id(ref["etapa"]), criterio={
                    "metodo": "Referencia experta directa", "referencia": ref["nombre"], "fundamento": ref["descripcion"]})
        for a in exp["analogias"]:
            k = nombre_id[a["instrumento"]]
            instrumentos[k].update(etapa=a["etapa"], criterio={
                "metodo": "Analogía con referencia experta", "referencia": a["referencia"], "fundamento": a["fundamento"]})
        excepciones = {x["clave"]: x for x in exp["lineas"]}
        for l in lineas:
            e = instrumentos[l["inst"]]["etapa"]
            l["etapaExcel"], l["etapasExcel"] = l["etapa"], list(l["etapas"])
            x = next((v for k, v in excepciones.items() if k.split("|")[0] == l["instrumento"] and l["linea"].startswith(k.split("|")[1])), None)
            if x:
                l["etapa"], l["etapas"], l["fundamentoExperto"] = x["etapa"], [x["etapa"]], x["fundamento"]
            else:
                l["etapa"] = e
                l["etapas"] = [] if e == "transversal" else [e]
            if l["instrumento"] in exp["ejes"]:
                l["transversal"] = exp["ejes"][l["instrumento"]]
        criterios.append({"aspecto": "Clasificación por etapas: criterio experto", "criterio": exp["criterio"] + (
            f" {sum(1 for v in instrumentos.values() if v.get('criterio', {}).get('metodo', '').startswith('Referencia'))} instrumentos "
            f"con referencia directa y {len(exp['analogias'])} por analogía.")})

    # Ajustes de clasificación con sustento en las bases oficiales (scripts/revisar_clasificacion.py + revisión)
    dec_path = Path(__file__).resolve().parent.parent / "data-fuente" / "decisiones_revision_bases.json"
    if dec_path.exists():
        dec = json.loads(dec_path.read_text(encoding="utf-8"))
        etiquetas = {x["c"]: x["t"] for l in lineas for x in l["apoyos"] + l["capacidades"]}
        por_id = {l["id"]: l for l in lineas}
        for a in dec["aceptadas"]:
            l = por_id[a["linea_id"]]
            if a["dimension"] == "mecanismo":
                if a["valor"] not in l["mecanismosComp"] and a["valor"] != l["mecanismo"]:
                    l["mecanismosComp"].append(a["valor"])
                etiqueta = a["valor"]
            else:
                campo = "apoyos" if a["dimension"] == "apoyo" else "capacidades"
                if not any(x["c"] == a["valor"] for x in l[campo]):
                    l[campo].append({"c": a["valor"], "t": etiquetas[a["valor"]], "ajuste": True})
                etiqueta = etiquetas[a["valor"]]
            l.setdefault("ajustes", []).append(
                {"dimension": a["dimension"], "valor": etiqueta, "fundamento": a["fundamento"], "cita": a["cita"]}
            )
        for f in dec["fuentes_a_corregir"]:
            por_id[f["linea_id"]]["notaFuente"] = f["nota"]
        criterios.append({
            "aspecto": "Revisión de la clasificación con las bases",
            "criterio": f"Se contrastó cada línea con sus bases y fichas oficiales. {len(dec['aceptadas'])} ajustes aceptados "
            f"(mecanismos complementarios, apoyos y capacidades explícitos en las bases), {len(dec['rechazadas'])} alertas "
            f"descartadas y {len(dec['fuentes_a_corregir'])} fuentes a corregir. {dec['criterio']} Los ajustes se marcan en "
            "la ficha de cada instrumento con la cita de la base.",
        })

    agencias = {a["nombre"]: a for a in P["agencias"]}
    instituciones = [
        {"id": k, "sigla": SIGLA.get(k, k), "nombre": v, "rol": agencias[k]["rol"], "color": agencias[k]["color"]}
        for k, v in INSTITUCIONES.items()
        if any(l["institucion"] == k for l in lineas)
    ]
    referencias = [
        {"id": r["id"], "etapa": stage_id(r["etapa"]), "nombre": r["nombre"], "descripcion": r["descripcion"],
         "instrumentos": r["instrumentos_ids"]}
        for r in P["referencia_etapas"]
    ]
    for ref in referencias:
        ref["instrumentos"] = ref["instrumentos"] + [k for k, v in instrumentos.items() if v.get("referencia") == ref["nombre"]]
    n_inst = len({l["inst"] for l in lineas})
    criterios[0]["criterio"] = (f"Universo empresarial revisado: {n_inst} instrumentos y {len(lineas)} líneas B20 (se incluyen públicos "
                                "mixtos con B20). Incluye los instrumentos de referencias expertas que no estaban en el portafolio: "
                                + ", ".join(sorted({l["instrumento"] for l in lineas if l["inst"] in instrumentos and instrumentos[l["inst"]].get("referencia")}))
                                + ".")
    out = {
        "fecha": "2026-10-30",
        "contacto": P["meta"].get("contacto"),
        "etapas": [{"id": k, "nombre": n, "orden": i + 1} for i, (k, n) in enumerate(ETAPAS)],
        "instituciones": instituciones,
        "criterios": criterios,
        "instrumentos": instrumentos,
        "referencias": referencias,
        "lineas": lineas,
    }
    # palabras clave extraídas por scripts/extraer_bases.py (bases oficiales y texto del portafolio)
    kw_path = Path(__file__).resolve().parent.parent / "data-fuente" / "palabras_clave.json"
    if kw_path.exists():
        kw = json.loads(kw_path.read_text(encoding="utf-8"))["instrumentos"]
        for k, v in out["instrumentos"].items():
            info = kw.get(k, {})
            v["kwBases"] = [[f, r, p] for f, r, p in info.get("bases", [])]
            v["kwPortafolio"] = [f for f, _, _ in info.get("portafolio", [])]
            v["fuentesLeidas"] = sum(1 for x in info.get("fuentes", []) if x["estado"].startswith("ok"))
        docs = [x for i in kw.values() for x in i.get("fuentes", [])]
        leidos = sum(1 for x in docs if x["estado"].startswith("ok"))
        con_bases = sum(1 for i in kw.values() if i.get("bases"))
        criterios.append({
            "aspecto": "Palabras clave y similitud",
            "criterio": "Cada instrumento tiene palabras clave calculadas con TF-IDF (términos frecuentes en el instrumento y "
            "poco frecuentes en el resto del portafolio, incluidas expresiones de dos palabras). Se extraen de sus bases y "
            f"fichas oficiales cuando pueden leerse ({leidos} de {len(docs)} documentos leídos; {con_bases} instrumentos con "
            "palabras clave de bases) y, en su defecto, del nombre, líneas, descripciones y sector registrados en el portafolio. "
            "La similitud combina esa cercanía de vocabulario (45 %) con la coincidencia de apoyos, capacidades, mecanismo y etapa.",
        })
    dest = Path(__file__).resolve().parent.parent / "src" / "data" / "portafolio.json"
    dest.write_text(json.dumps(out, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    n_inst = len({l["inst"] for l in lineas})
    print(f"{len(lineas)} líneas · {n_inst} instrumentos · {len(instituciones)} instituciones -> {dest}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
