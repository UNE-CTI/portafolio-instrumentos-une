"""Contrasta la clasificación del Excel con el texto de las bases oficiales de cada línea.

Requiere haber corrido scripts/extraer_bases.py (usa los documentos en caché).
Salida: hojas "Revisión con bases" y "Montos y cofinanciamiento" en
data-fuente/Clasificacion_etapas_B20_ajustada_palabras_clave.xlsx, y data-fuente/revision_bases.json.

Es una revisión asistida: cada alerta trae la cantidad de menciones y un fragmento de la base para que una
persona decida. Tipos de alerta:
  - Posible omisión: las bases mencionan reiteradamente algo que la línea no tiene clasificado.
  - Sin respaldo en bases: la línea tiene un valor que su base (extensa) no menciona nunca.
  - Vigencia: el documento no menciona 2026.
"""
import importlib.util
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import urlparse

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

RAIZ = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("eb", RAIZ / "scripts" / "extraer_bases.py")
eb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(eb)
norm = eb.norm

# Reglas: dimensión -> valor -> (patrón sobre texto normalizado, mínimo de menciones para sugerir omisión)
CREDITO = r"\bprestamo|tasa de interes|amortizacion|\bcreditos?\b(?! fiscal)"
REGLAS = {
    "mecanismo": {
        "Crédito o financiamiento reembolsable": (CREDITO, 6),
        "Transferencia no reembolsable / subsidio": (r"no reembolsable|subsidio|subvencion|cofinanci|aporte no|reintegr|voucher", 4),
        "Garantía o reducción de riesgo/costo financiero": (r"\bgarantia", 5),
        "Capital o coinversión": (r"coinversion|capital emprendedor|nota convertible|participacion accionaria|\bequity\b", 4),
        "Incentivo fiscal": (r"credito fiscal|exoneracion|\birae\b|beneficio fiscal", 4),
        "Premio o reconocimiento": (r"\bpremio|galardon", 4),
    },
    "apoyo": {
        "A03": (CREDITO, 6),
        "A04": (r"\bgarantia|bonificacion de (?:la )?tasa", 5),
        "A05": (r"coinversion|capital emprendedor|nota convertible", 4),
        "A06": (r"credito fiscal|exoneracion|\birae\b", 4),
        "A09": (r"capacitacion|\bcursos?\b|\bformacion", 8),
        "A10": (r"mentor|incubac|aceleracion|acelerador", 5),
        "A14": (r"certificacion|\bsello\b|norma iso|\biso \d", 5),
        "A15": (r"patent|propiedad intelectual|licenciamiento", 4),
        "A16": (r"\bferias?\b|mision(?:es)? comercial|ronda de negocios|rueda de negocios", 4),
        "A21": (r"compras? publicas?|licitacion", 4),
        "A23": (r"\bpremio", 4),
        "A25": (r"puestos? de trabajo|nuevos puestos|contratacion de personal|generacion de empleo", 4),
        "A26": (r"traduc", 3),
    },
    "capacidad": {
        "C2": (r"digital|software|comercio electronico|ciberseguridad", 6),
        "C4": (r"investigacion y desarrollo|\bi\s?\+\s?d\b|investigacion aplicada", 4),
        "C9": (r"exporta|internacionaliz|mercados? (?:externos?|internacionales?)", 6),
        "C11": (r"patent|propiedad intelectual", 4),
        "C12": (r"eficiencia energetica|economia circular|ambiental|sostenib|residuos|emisiones|descarboniz", 6),
    },
}
NOMBRES = {**{c: c for c in REGLAS["mecanismo"]}}


def fragmento(texto, patron, ancho=110):
    """Primera frase de la base (texto original) que contiene el patrón."""
    n = norm(texto)
    m = re.search(patron, n)
    if not m:
        return ""
    a, b = max(0, m.start() - ancho), min(len(texto), m.end() + ancho)
    return "…" + re.sub(r"\s+", " ", texto[a:b]).strip() + "…"


MONTO = re.compile(
    r"(?:hasta|maxim[oa]s?|tope|monto maximo|no podra superar|no superior a)[^.\n]{0,60}?"
    r"((?:\$|u\$s|us\$|usd|ui|unidades indexadas|pesos uruguayos|dolares)\s?[\d\.\,]+(?:\s?(?:millones|mil))?"
    r"|[\d\.\,]{4,}\s?(?:ui|unidades indexadas|pesos|dolares|usd|u\$s))",
)
PORC = re.compile(r"(\d{2,3})\s?%\s?(?:del|de los|de la)?\s?(?:costo|gasto|proyecto|total|monto|inversion|presupuesto)")


def main():
    datos = json.loads((RAIZ / "src" / "data" / "portafolio.json").read_text(encoding="utf-8"))
    lineas = datos["lineas"]
    uso = Counter(u for i in {l["inst"] for l in lineas} for u in {x for l in lineas if l["inst"] == i for x in (l["urlBases"], l["urlFicha"]) if x})

    textos = {}
    for l in lineas:
        for u in (l["urlBases"], l["urlFicha"]):
            if u and u not in textos:
                textos[u] = eb.descargar(u)[1]
    dom_lineas = defaultdict(Counter)
    for u, t in textos.items():
        dom_lineas[urlparse(u).netloc.replace("www.", "")].update({x.strip() for x in t.splitlines() if x.strip()})

    def limpio(u):
        dom = dom_lineas[urlparse(u).netloc.replace("www.", "")]
        return "\n".join(x for x in textos[u].splitlines() if x.strip() and dom[x.strip()] < 2)

    # mecanismos complementarios declarados en el Excel original (cuentan como ya clasificados)
    wb0 = openpyxl.load_workbook(RAIZ / "data-fuente" / "Clasificacion_etapas_B20_ajustada.xlsx", read_only=True, data_only=True)
    filas = list(wb0["Líneas originales B20"].iter_rows(values_only=True))
    ci = filas[0].index("mecanismos_complementarios")
    complementarios = {
        f[0]: {re.sub(r"^M\d+\s+", "", x.strip()) for x in (f[ci] or "").split(";") if x.strip()} for f in filas[1:] if f[0]
    }

    alertas, montos = [], []
    for l in lineas:
        urls = [u for u in dict.fromkeys((l["urlBases"], l["urlFicha"])) if u and uso[u] < 2]
        texto = "\n".join(limpio(u) for u in urls)
        if len(texto) < 1500:
            continue
        n = norm(texto)
        url = urls[0]
        actuales = {
            "mecanismo": {l["mecanismo"]} | complementarios.get(l["id"], set()),
            "apoyo": {a["c"] for a in l["apoyos"]},
            "capacidad": {c["c"] for c in l["capacidades"]},
        }
        nombres = {
            "apoyo": {a["c"]: a["t"] for x in lineas for a in x["apoyos"]},
            "capacidad": {c["c"]: c["t"] for x in lineas for c in x["capacidades"]},
        }
        base = {"linea_id": l["id"], "institucion": l["institucion"], "instrumento": l["instrumento"], "linea": l["linea"], "url": url}
        for dim, reglas in REGLAS.items():
            for valor, (patron, minimo) in reglas.items():
                cuenta = len(re.findall(patron, n))
                etiqueta = valor if dim == "mecanismo" else f"{valor} {nombres[dim].get(valor, '')}".strip()
                if cuenta >= minimo and valor not in actuales[dim]:
                    alertas.append({**base, "dimension": dim, "tipo": "Posible omisión", "valor": etiqueta,
                                    "en_excel": "; ".join(sorted(actuales[dim])), "menciones": cuenta,
                                    "fragmento": fragmento(texto, patron)})
                elif cuenta == 0 and valor in actuales[dim] and len(texto) >= 5000:
                    alertas.append({**base, "dimension": dim, "tipo": "Sin respaldo en bases", "valor": etiqueta,
                                    "en_excel": "; ".join(sorted(actuales[dim])), "menciones": 0, "fragmento": ""})
        anios = [int(a) for a in re.findall(r"\b(20[12]\d)\b", n)]
        if anios and 2026 not in anios:
            alertas.append({**base, "dimension": "vigencia", "tipo": "Vigencia", "valor": f"El documento menciona hasta {max(anios)}",
                            "en_excel": l["vigencia"], "menciones": 0, "fragmento": ""})
        m = list(dict.fromkeys(x.group(1).strip() for x in MONTO.finditer(n)))[:3]
        p = sorted({int(x) for x in PORC.findall(n) if 10 <= int(x) <= 100}, reverse=True)[:3]
        if m or p:
            montos.append({**base, "montos": "; ".join(m), "porcentajes": "; ".join(f"{x} %" for x in p)})

    (RAIZ / "data-fuente" / "revision_bases.json").write_text(
        json.dumps({"alertas": alertas, "montos": montos}, ensure_ascii=False, indent=1), encoding="utf-8")

    destino = RAIZ / "data-fuente" / "Clasificacion_etapas_B20_ajustada_palabras_clave.xlsx"
    wb = openpyxl.load_workbook(destino)
    for nombre in ("Revisión con bases", "Montos y cofinanciamiento"):
        if nombre in wb.sheetnames:
            del wb[nombre]
    h = wb.create_sheet("Revisión con bases")
    cols = ["linea_id", "Institución", "Instrumento", "Línea", "Dimensión", "Tipo de alerta", "Valor detectado",
            "Clasificación en Excel", "Menciones en bases", "Fragmento de la base", "URL", "Decisión", "Comentario"]
    h.append(cols)
    orden = {"Posible omisión": 0, "Sin respaldo en bases": 1, "Vigencia": 2}
    for a in sorted(alertas, key=lambda a: (orden[a["tipo"]], -a["menciones"])):
        h.append([a["linea_id"], a["institucion"], a["instrumento"], a["linea"], a["dimension"], a["tipo"], a["valor"],
                  a["en_excel"], a["menciones"], a["fragmento"], a["url"], "", ""])
    h2 = wb.create_sheet("Montos y cofinanciamiento")
    h2.append(["linea_id", "Institución", "Instrumento", "Línea", "Montos máximos detectados", "Porcentajes detectados", "URL"])
    for m in montos:
        h2.append([m["linea_id"], m["institucion"], m["instrumento"], m["linea"], m["montos"], m["porcentajes"], m["url"]])
    for hoja, anchos in ((h, [16, 12, 30, 30, 11, 20, 34, 34, 10, 70, 40, 14, 30]), (h2, [16, 12, 30, 34, 40, 20, 50])):
        for c in hoja[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="27428C")
        hoja.freeze_panes = "A2"
        for i, w in enumerate(anchos, 1):
            hoja.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
        for fila in hoja.iter_rows(min_row=2):
            for c in fila:
                c.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(destino)
    print(Counter(a["tipo"] for a in alertas), Counter(a["dimension"] for a in alertas), f"montos en {len(montos)} líneas")


if __name__ == "__main__":
    main()
