"""Descarga las bases y fichas oficiales de cada instrumento, extrae su texto y calcula palabras clave.

Salidas:
  data-fuente/bases/                      caché de documentos descargados (PDF / HTML) y su texto
  data-fuente/palabras_clave.json         palabras clave por instrumento (bases y portafolio) con pesos
  data-fuente/Clasificacion_etapas_B20_ajustada_palabras_clave.xlsx
                                          copia del Excel de insumos con las palabras clave incorporadas

Uso:
  python3 scripts/extraer_bases.py data-fuente/Clasificacion_etapas_B20_ajustada.xlsx
  (requiere src/data/portafolio.json generado por build_data.py; vuelva a correr build_data.py después)

Las palabras clave se calculan con TF-IDF: pesan más los términos frecuentes en un instrumento y raros en el
resto del portafolio. Se consideran palabras sueltas y expresiones de dos palabras. Los términos genéricos de
bases (plazos, formularios, artículos) y del portafolio (programa, fondo, empresas) se descartan.
"""
import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
import time
import unicodedata
import urllib.request
from collections import Counter, defaultdict
from datetime import date
from html.parser import HTMLParser
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

RAIZ = Path(__file__).resolve().parent.parent
CACHE = RAIZ / "data-fuente" / "bases"
UA = "Mozilla/5.0 (compatible; UNE-mapa-instrumentos/1.0)"

STOP = set(
    """de la el los las un una unos unas y o u e a en con por para del al que se su sus sin sobre entre como mas este esta
    estos estas ese esa eso lo le les ya no si es son ser fue sera han hasta desde otro otra otros otras cada mediante traves
    cual cuales donde muy tambien asi dicho dicha dichos dichas mismo misma mismos mismas todo toda todos todas cuando
    apoyo apoyos programa programas fondo fondos instrumento instrumentos linea lineas empresa empresas empresarial
    empresariales proyecto proyectos financiamiento financia financiar cofinanciamiento reembolsable uruguay uruguayo
    uruguaya uruguayos uruguayas nacional desarrollo desarrollar fortalecer fortalecimiento mejora mejorar mejoras acceso
    facilitar promover apoyar convocatoria convocatorias servicio servicios estrategico estrategica destinado destinada
    dirigido dirigida orientado orientada busca permite parte total parcial sector sectores nuevo nuevos nueva nuevas
    accion acciones implementar implementacion especifico especificos especifica especificas amplia ampliar
    bases base condiciones postulacion postulaciones postular postulante postulantes articulo articulos anexo anexos
    plazo plazos formulario formularios solicitud solicitudes debera deberan presente presentes presentar presentacion
    numero fecha fechas dias mes meses ano anos cual caso casos forma manera efecto efectos marco respecto ello
    agencia ministerio instituto institucion instituciones inciso literal punto puntos pagina web sitio http https www
    mail correo telefono contacto consultas informacion click aqui ver mas leer inicio menu buscar noticias
    beneficiario beneficiarios evaluacion evaluar seleccion criterios requisito requisitos documentacion documento
    documentos podra podran pueden puede debe deben correspondiente correspondientes vigente vigentes general generales
    objetivo objetivos actividad actividades monto montos maximo minimo hasta pesos dolares unidades indexadas
    nucleo comun finalidad clasificacion reclasifica estrategicamente resultado resultados operativo operativos tener
    reciben recibir aprobadas aprobados diferenciados diferenciadas modificar previamente sola linea operativa
    uno dos tres cuatro cinco seis siete ocho nueve diez once doce veinte treinta cuarenta cincuenta sesenta setenta ochenta
    noventa cien ciento cientos doscientos trescientos cuatrocientos quinientos seiscientos setecientos ochocientos
    novecientos mil millon millones veintidos veintiuno primera primer segunda segundo tercera tercer
    enero febrero marzo abril mayo junio julio agosto setiembre septiembre octubre noviembre diciembre lunes martes
    miercoles jueves viernes sabado domingo hora horas semana semanas tendra tendran podras podra haciendo hacer hace
    lleva llevar adelante sino estamos pudiera bueno mejor siendo quien quienes aquellos aquellas aquel aquella
    video videos reproducir descargar descarga page bottom links link siguenos siguelos agradecemos contactanos info
    docx xlsx pdf clic tribunal firma aclaracion timbre covid actas cerradas cerrado proxima proximo edicion ediciones
    llamado llamados abierto abierta abiertas inscripciones inscripcion
    ademas pudiendo pueda puedan sean sea cuyos cuyas cuyo cuya tiene tienen tenga tengan segun siguientes siguiente hayan
    haya necesario necesaria realizar realizado realizada caso logrando sido tenido manera junto juntos traves dentro
    fuera mientras luego antes despues durante aunque sobre todo bien solo sola solamente etc usuario usuarios mostrar
    lanzo comienza comenzar desea desean deseen interes interesados interesadas cualquier alguna alguno algunos algunas
    mariela rodriguez giuda clemente eusebio altuna lasa graciela fernandez""".split()
)


def norm(s):
    return "".join(c for c in unicodedata.normalize("NFD", (s or "").lower()) if unicodedata.category(c) != "Mn")


STOPN = {norm(w) for w in STOP}


def tokens(texto):
    """Lista de (forma, raíz); la raíz son los 6 primeros caracteres normalizados."""
    out = []
    for w in re.findall(r"[a-záéíóúüñ]+", (texto or "").lower()):
        n = norm(w)
        # descarta palabras vacías y restos de URL o códigos (4 consonantes seguidas)
        if len(n) < 4 or n in STOPN or re.search(r"[bcdfghjklmnpqrstvwxz]{4}", n):
            out.append(None)  # corta expresiones de dos palabras
            continue
        out.append((w, n[:6]))
    return out


def terminos(texto):
    """Cuenta raíces de palabras y de pares consecutivos; guarda la forma más frecuente de cada una."""
    cuenta, formas = Counter(), defaultdict(Counter)
    toks = tokens(texto)
    for i, t in enumerate(toks):
        if not t:
            continue
        cuenta[t[1]] += 1
        formas[t[1]][t[0]] += 1
        if i + 1 < len(toks) and toks[i + 1]:
            r, f = f"{t[1]} {toks[i + 1][1]}", f"{t[0]} {toks[i + 1][0]}"
            cuenta[r] += 1
            formas[r][f] += 1
    return cuenta, formas


def tfidf(docs, top=25, max_df=0.4):
    n = len(docs)
    df = Counter()
    for c, _ in docs.values():
        df.update(set(c))
    out = {}
    for k, (c, formas) in docs.items():
        pesos = {}
        for r, f in c.items():
            if df[r] > max(2, n * max_df):
                continue
            # las expresiones de dos palabras solo cuentan si se repiten en el documento
            if " " in r and f < 2:
                continue
            pesos[r] = (1 + math.log(f)) * math.log((n + 1) / (df[r] + 0.5)) * (1.15 if " " in r else 1)
        norma = math.sqrt(sum(x * x for x in pesos.values())) or 1
        orden = sorted(pesos.items(), key=lambda x: -x[1])[:top]
        out[k] = [[formas[r].most_common(1)[0][0], r, round(p / norma, 4)] for r, p in orden]
    return out


class Texto(HTMLParser):
    SALTAR = {"script", "style", "nav", "footer", "header", "noscript", "svg", "form"}

    def __init__(self):
        super().__init__()
        self.partes, self.nivel = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SALTAR:
            self.nivel += 1

    def handle_endtag(self, tag):
        if tag in self.SALTAR and self.nivel:
            self.nivel -= 1

    def handle_data(self, data):
        if not self.nivel and data.strip():
            self.partes.append(data.strip())


def descargar(url):
    """Devuelve (estado, texto). Usa la caché local si el documento ya se descargó."""
    h = hashlib.sha1(url.encode()).hexdigest()[:16]
    txt = CACHE / f"{h}.txt"
    if txt.exists():
        return "ok (caché)", txt.read_text(encoding="utf-8")
    for intento in range(4):
        time.sleep(1.5 * intento)  # pausa creciente: algunos sitios limitan pedidos seguidos (HTTP 429)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=40) as r:
                datos, tipo = r.read(), r.headers.get("Content-Type", "")
            break
        except Exception as e:  # red bloqueada, 404, certificado, etc.
            error = f"no accesible: {type(e).__name__}: {str(e)[:120]}"
            if "429" not in error and "104" not in error:
                return error, ""
    else:
        return error, ""
    if datos[:4] == b"%PDF" or "pdf" in tipo:
        pdf = CACHE / f"{h}.pdf"
        pdf.write_bytes(datos)
        texto = ""
        if shutil.which("pdftotext"):
            texto = subprocess.run(["pdftotext", "-q", str(pdf), "-"], capture_output=True, text=True).stdout
        if len(texto.strip()) < 200:
            from pypdf import PdfReader

            texto = "\n".join((p.extract_text() or "") for p in PdfReader(str(pdf)).pages)
        estado = "ok (PDF)" if texto.strip() else "PDF sin texto extraíble (posible escaneo)"
    else:
        (CACHE / f"{h}.html").write_bytes(datos)
        p = Texto()
        p.feed(datos.decode("utf-8", errors="ignore"))
        texto = "\n".join(p.partes)
        estado = "ok (HTML)"
    txt.write_text(texto, encoding="utf-8")
    return estado, texto


def main(excel_path):
    CACHE.mkdir(parents=True, exist_ok=True)
    datos = json.loads((RAIZ / "src" / "data" / "portafolio.json").read_text(encoding="utf-8"))
    por_inst = defaultdict(list)
    for l in datos["lineas"]:
        por_inst[l["inst"]].append(l)

    # 1. bases y fichas oficiales. Las páginas compartidas por 3 o más instrumentos (listados generales de
    #    convocatorias) se consultan pero no aportan palabras clave: no describen a ningún instrumento en particular.
    uso = Counter(u for ls in por_inst.values() for u in {x for l in ls for x in (l["urlBases"], l["urlFicha"]) if x})
    urls_inst = {k: list(dict.fromkeys(u for l in ls for u in (l["urlBases"], l["urlFicha"]) if u)) for k, ls in por_inst.items()}
    descargas = {}
    for k, urls in urls_inst.items():
        for u in urls:
            if u not in descargas:
                descargas[u] = descargar(u)
                print(f"{por_inst[k][0]['instrumento'][:40]:40} {descargas[u][0][:60]:60} {u[:70]}")
                time.sleep(0.4)

    # Plantilla de cada sitio: líneas que se repiten en 2 o más documentos del mismo dominio (menús, pies, avisos)
    from urllib.parse import urlparse

    lineas_dom = defaultdict(Counter)
    for u, (_, t) in descargas.items():
        lineas_dom[urlparse(u).netloc.replace("www.", "")].update({x.strip() for x in t.splitlines() if x.strip()})

    def limpiar(u, t):
        dom = lineas_dom[urlparse(u).netloc.replace("www.", "")]
        t = "\n".join(x for x in t.splitlines() if x.strip() and dom[x.strip()] < 2)
        palabras = re.findall(r"[a-záéíóúñ]+", t.lower())
        # algunos PDF codifican la "a" como "á" (p. ej. "idiomá"): si es masivo, se corrige
        if palabras and sum(w.endswith("á") for w in palabras) / len(palabras) > 0.03:
            t = t.replace("á", "a")
        return t

    fuentes, textos_bases = {}, {}
    for k, urls in urls_inst.items():
        registros, partes = [], []
        for u in urls:
            estado, texto = descargas[u]
            limpio = limpiar(u, texto) if texto else ""
            compartida = uso[u] >= 2
            registros.append({"url": u, "estado": estado, "caracteres": len(limpio), "compartida": compartida})
            if not compartida:
                partes.append(limpio)
        fuentes[k] = registros
        textos_bases[k] = "\n".join(partes)

    # 2. texto del portafolio (siempre disponible)
    textos_port = {
        k: " ".join(
            [ls[0]["instrumento"]] * 2
            + [datos["instrumentos"].get(k, {}).get("justificacion") or ""]
            + [x for l in ls for x in (l["linea"], l["descripcion"], l["sector"] or "")]
        )
        for k, ls in por_inst.items()
    }

    con_bases = {k: t for k, t in textos_bases.items() if len(t) >= 1500}
    kw_bases = tfidf({k: terminos(t) for k, t in con_bases.items()}) if len(con_bases) >= 10 else {}
    kw_port = tfidf({k: terminos(t) for k, t in textos_port.items()}, top=15, max_df=0.5)

    salida = {
        "generado": date.today().isoformat(),
        "instrumentos": {
            k: {
                "instrumento": ls[0]["instrumento"],
                "institucion": ls[0]["institucion"],
                "fuentes": fuentes[k],
                "bases": kw_bases.get(k, []),
                "portafolio": kw_port.get(k, []),
            }
            for k, ls in por_inst.items()
        },
    }
    (RAIZ / "data-fuente" / "palabras_clave.json").write_text(
        json.dumps(salida, ensure_ascii=False, indent=1), encoding="utf-8"
    )

    # 3. Excel de insumos con las palabras clave incorporadas
    wb = openpyxl.load_workbook(excel_path)
    ws = wb["Instrumentos B20"]
    cab = [c.value for c in ws[1]]
    col_b = len(cab) + 1
    col_p = len(cab) + 2
    col_e = len(cab) + 3
    for col, titulo in [(col_b, "Palabras clave (bases)"), (col_p, "Palabras clave (portafolio)"), (col_e, "Estado de acceso a bases")]:
        ws.cell(1, col, titulo).font = Font(bold=True)
    for fila in range(2, ws.max_row + 1):
        k = ws.cell(fila, 1).value
        if not k:
            continue
        info = salida["instrumentos"].get(k)
        if not info:
            ws.cell(fila, col_e, "Retirado de la selección B20")
            continue
        ws.cell(fila, col_b, "; ".join(f for f, _, _ in info["bases"][:15]))
        ws.cell(fila, col_p, "; ".join(f for f, _, _ in info["portafolio"][:12]))
        ok = sum(1 for f in info["fuentes"] if f["estado"].startswith("ok"))
        ws.cell(fila, col_e, f"{ok} de {len(info['fuentes'])} documentos leídos")
    for col, ancho in [(col_b, 70), (col_p, 60), (col_e, 26)]:
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = ancho

    if "Palabras clave" in wb.sheetnames:
        del wb["Palabras clave"]
    hoja = wb.create_sheet("Palabras clave")
    titulos = ["instrumento_id", "Institución", "Instrumento", "Origen", "Rango", "Palabra o expresión", "Peso TF-IDF"]
    hoja.append(titulos)
    for k, info in salida["instrumentos"].items():
        for origen in ("bases", "portafolio"):
            for i, (forma, _, peso) in enumerate(info[origen], 1):
                hoja.append([k, info["institucion"], info["instrumento"], origen, i, forma, peso])
    if "Fuentes consultadas" in wb.sheetnames:
        del wb["Fuentes consultadas"]
    fu = wb.create_sheet("Fuentes consultadas")
    fu.append(["instrumento_id", "Institución", "Instrumento", "URL", "Estado", "Caracteres extraídos"])
    for k, info in salida["instrumentos"].items():
        for f in info["fuentes"]:
            nota = " · página compartida con otro instrumento: no aporta palabras clave" if f.get("compartida") else ""
            fu.append([k, info["institucion"], info["instrumento"], f["url"], f["estado"] + nota, f["caracteres"]])
    for h in (hoja, fu):
        for c in h[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="27428C")
            c.alignment = Alignment(vertical="center")
        h.freeze_panes = "A2"
        for i, ancho in enumerate([16, 14, 44, 12, 8, 40, 12] if h is hoja else [16, 14, 44, 90, 50, 12], 1):
            h.column_dimensions[openpyxl.utils.get_column_letter(i)].width = ancho

    destino = RAIZ / "data-fuente" / "Clasificacion_etapas_B20_ajustada_palabras_clave.xlsx"
    wb.save(destino)
    leidos = sum(1 for v in fuentes.values() for f in v if f["estado"].startswith("ok"))
    total = sum(len(v) for v in fuentes.values())
    print(f"\nDocumentos leídos: {leidos} de {total} · instrumentos con bases: {len(kw_bases)} de {len(por_inst)}")
    print(f"Excel: {destino}")


if __name__ == "__main__":
    main(sys.argv[1])
