"""Incorpora al Excel revisado la clasificación por etapas según el criterio experto y los instrumentos nuevos.

Entrada:  data-fuente/Clasificacion_etapas_B20_revisada_bases.xlsx (de aplicar_revision_excel.py)
          src/data/portafolio.json (de build_data.py, con criterio_experto.json e instrumentos_incorporados.json)
Salida:   el mismo Excel, con la hoja "Criterio experto", columnas de etapa experta y los instrumentos incorporados.
"""
import json
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

RAIZ = Path(__file__).resolve().parent.parent
DESTINO = RAIZ / "data-fuente" / "Clasificacion_etapas_B20_revisada_bases.xlsx"
NUEVO = PatternFill("solid", fgColor="DCE8F7")
CAMBIO = PatternFill("solid", fgColor="F6E7C8")
CABECERA = PatternFill("solid", fgColor="27428C")
NOMBRES = {
    "ideacion": "Ideación y prueba", "id": "Investigación y desarrollo", "marcha": "Puesta en marcha",
    "consolidacion": "Consolidación y crecimiento", "internacional": "Internacionalización y escalamiento", "transversal": "Transversal",
}


def main():
    d = json.loads((RAIZ / "src" / "data" / "portafolio.json").read_text(encoding="utf-8"))
    src = (RAIZ / "data-fuente" / "portafolio_data_30_10_2026.js").read_text(encoding="utf-8")
    anterior = {k: v["etapa_principal"].split(". ")[-1] for k, v in json.loads(src[src.index("=") + 1:].strip().rstrip(";"))["instrumentos"].items()}
    inst, lineas = d["instrumentos"], d["lineas"]
    por_inst = {}
    for l in lineas:
        por_inst.setdefault(l["inst"], []).append(l)
    wb = openpyxl.load_workbook(DESTINO)

    # 1. hoja resumen
    if "Criterio experto" in wb.sheetnames:
        del wb["Criterio experto"]
    h = wb.create_sheet("Criterio experto", 0)
    h.append(["instrumento_id", "Institución", "Instrumento", "Etapa anterior", "Etapa según criterio experto", "Cambio",
              "Método", "Referencia experta aplicada", "Fundamento"])
    for k, ls in sorted(por_inst.items(), key=lambda x: (x[1][0]["institucion"], x[1][0]["instrumento"])):
        m = inst[k]
        ant = anterior.get(k, "— (instrumento incorporado)")
        nueva = NOMBRES[m["etapa"]]
        cambio = "Incorporado" if k not in anterior else ("Sí" if ant != nueva else "No")
        h.append([k, ls[0]["institucion"], ls[0]["instrumento"], ant, nueva, cambio,
                  m["criterio"]["metodo"], m["criterio"]["referencia"], m["criterio"]["fundamento"]])
        if cambio != "No":
            for c in h[h.max_row]:
                c.fill = NUEVO if cambio == "Incorporado" else CAMBIO

    # 2. columnas de etapa experta por línea
    la = wb["Líneas B20 ajustadas"]
    cab = [c.value for c in la[1]]
    base = len(cab) + 1
    for i, t in enumerate(["Etapa criterio experto", "Etapas cubiertas (criterio experto)", "Cambio de etapa"]):
        la.cell(1, base + i, t).font = Font(bold=True)
    filas = {la.cell(r, 1).value: r for r in range(2, la.max_row + 1) if la.cell(r, 1).value}
    for l in lineas:
        if l["id"] not in filas:
            continue
        r = filas[l["id"]]
        cambio = l["etapa"] != l["etapaExcel"] or set(l["etapas"]) != set(l["etapasExcel"])
        la.cell(r, base, NOMBRES[l["etapa"]])
        la.cell(r, base + 1, "; ".join(NOMBRES[e] for e in l["etapas"]) or "Transversal")
        la.cell(r, base + 2, "Sí" if cambio else "No")
        if cambio:
            for i in range(3):
                la.cell(r, base + i).fill = CAMBIO

    ib = wb["Instrumentos B20"]
    cab_i = [c.value for c in ib[1]]
    bi = len(cab_i) + 1
    for i, t in enumerate(["Etapa criterio experto", "Método", "Referencia experta aplicada", "Fundamento criterio experto"]):
        ib.cell(1, bi + i, t).font = Font(bold=True)
    for r in range(2, ib.max_row + 1):
        k = ib.cell(r, 1).value
        if k in inst and k in por_inst:
            c = inst[k]["criterio"]
            for i, v in enumerate([NOMBRES[inst[k]["etapa"]], c["metodo"], c["referencia"], c["fundamento"]]):
                ib.cell(r, bi + i, v)

    # 3. instrumentos incorporados (no estaban en el Excel original)
    nuevos = [l for l in lineas if l["inst"] not in anterior]
    lo = wb["Líneas originales B20"]
    co = {c.value: i + 1 for i, c in enumerate(lo[1])}
    for l in nuevos:
        if l["id"] in filas:
            continue
        valores = {
            "linea_id": l["id"], "instrumento_id": l["inst"], "institución": l["institucion"], "instrumento": l["instrumento"],
            "línea": l["linea"], "público_B20": l["publico"], "estado_2026": "ACTIVO 2026", "tipo_vigencia": l["vigencia"],
            "desafío_empresarial": l["desafio"], "finalidad_principal": l["finalidad"], "mecanismo_principal": l["mecanismo"],
            "capacidades_códigos": ";".join(c["c"] for c in l["capacidades"]),
            "capacidades_empresariales": "; ".join(f"{c['c']} {c['t']}" for c in l["capacidades"]),
            "apoyos_códigos": ";".join(a["c"] for a in l["apoyos"]),
            "apoyos_concretos": "; ".join(f"{a['c']} {a['t']}" for a in l["apoyos"]),
            "detalle_del_apoyo": l["descripcion"], "síntesis_línea": l["sintesis"], "cobertura_documental": l["cobertura"],
            "url_ficha": l["urlFicha"], "url_bases": l["urlBases"], "observaciones_fuente": l["observaciones"],
            "confianza": l["confianza"], "estado_revisión": l["revision"],
        }
        r = lo.max_row + 1
        for k, v in valores.items():
            if k in co:
                lo.cell(r, co[k], v).fill = NUEVO
        r = la.max_row + 1
        fila = {"linea_id": l["id"], "instrumento_id": l["inst"], "Institución": l["institucion"], "Instrumento": l["instrumento"],
                "Línea": l["linea"], "Etapa principal": NOMBRES[l["etapa"]], "Referencia experta": l["referencia"],
                "Fundamento del ajuste": l["fundamento"], "Descripción del apoyo en portafolio": l["descripcion"],
                "Fuente oficial declarada": l["urlFicha"], "URL bases declarada": l["urlBases"], "Confianza": l["confianza"],
                "Tipo de sustento": "Referencia experta + bases oficiales", "Estado 2026 original": "ACTIVO 2026"}
        for k, v in fila.items():
            if k in cab:
                la.cell(r, cab.index(k) + 1, v).fill = NUEVO
        for nombre in NOMBRES.values():
            if nombre in cab:
                la.cell(r, cab.index(nombre) + 1, 1 if nombre == NOMBRES[l["etapa"]] else 0).fill = NUEVO
        la.cell(r, base, NOMBRES[l["etapa"]]).fill = NUEVO
        la.cell(r, base + 1, "; ".join(NOMBRES[e] for e in l["etapas"])).fill = NUEVO
        la.cell(r, base + 2, "Incorporado").fill = NUEVO
    for k in {l["inst"] for l in nuevos}:
        r = ib.max_row + 1
        ls = por_inst[k]
        c = inst[k]["criterio"]
        for i, v in enumerate([k, ls[0]["institucion"], ls[0]["instrumento"], len(ls), NOMBRES[inst[k]["etapa"]], None,
                               "Instrumento incorporado: referencia experta sin instrumento en el portafolio"]):
            ib.cell(r, i + 1, v).fill = NUEVO
        for i, v in enumerate([NOMBRES[inst[k]["etapa"]], c["metodo"], c["referencia"], c["fundamento"]]):
            ib.cell(r, bi + i, v).fill = NUEVO

    for c in h[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = CABECERA
    h.freeze_panes = "A2"
    for i, w in enumerate([16, 12, 40, 26, 30, 11, 30, 36, 80], 1):
        h.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    for fila in h.iter_rows(min_row=2):
        for c in fila:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(DESTINO)
    cambios = sum(1 for r in h.iter_rows(min_row=2, values_only=True) if r[5] == "Sí")
    print(f"Criterio experto: {h.max_row - 1} instrumentos, {cambios} cambios de etapa, {len({l['inst'] for l in nuevos})} incorporados")


if __name__ == "__main__":
    main()
